// ==================================================
// 📦 VERIFICAÇÃO BÁSICA DAS BIBLIOTECAS
// ==================================================
const fs = require("fs");
const { execSync } = require("child_process");
const NodeCache = require("node-cache");

const dependencias = [
    "@whiskeysockets/baileys",
    "pino",
    "qrcode-terminal",
    "chalk"
];

console.log("🔍 VERIFICANDO BIBLIOTECAS...");
dependencias.forEach(pacote => {
    try { require.resolve(pacote); }
    catch {
        console.log(`📥 INSTALANDO: ${pacote}`);
        execSync(`npm install ${pacote} --save`, { stdio: "inherit" });
    }
});

// --- DEPENDÊNCIAS DO BOT ---
const {
    default: makeWASocket,
    useMultiFileAuthState,
    fetchLatestBaileysVersion,
    DisconnectReason
} = require("@whiskeysockets/baileys");
const pino = require("pino");
const qrcode = require("qrcode-terminal");
const path = require("path");
const readline = require("readline");

// --- ARQUIVOS DE CONFIGURAÇÃO ---
const config = require("./config");
const startInfo = require("./start");

// 🔹 GERENCIAMENTO DE GRUPO E PERMISSÕES
const {
    grupoHandler,
    groupEvents,
    verificarAntis,
    isAdmin,
    getDB,
    saveDB,
    normalize
} = require("./src/grupo");

// ✅ SISTEMA DE NÍVEL, MOEDAS E EVOLUÇÃO
const { processLevel } = require("./src/level");

// ✅🔑 INTELIGÊNCIA ARTIFICIAL
const { gerenciarModoIA, processarIA, normalizarTexto } = require("./src/mikasa-ia.js");

// 🔹 CONTROLES INTERNOS
const aguardandoResposta = new Map();

// ==================================================
// 🛡️ REDE DE SEGURANÇA GLOBAL — ISSO CORRIGE O BOT "REINICIANDO SOZINHO"
// ==================================================
// Antes, qualquer erro não tratado dentro de um comando derrubava o
// processo Node inteiro — e como o bot normalmente roda sob um gerenciador
// de processo (pm2, systemd, nodemon, etc), ele reiniciava sozinho. Isso
// costuma aparecer bem depois que alguém fica um tempo sem usar o bot,
// porque geralmente é a PRÓXIMA mensagem/comando executado que dispara um
// erro que já estava "esperando" a próxima chamada de alguma função. Com
// esses dois handlers, o processo NUNCA morre por causa de um erro de
// comando — ele só loga o erro no console e continua rodando normalmente.
process.on("unhandledRejection", (motivo) => {
    console.error("⚠️ [PROMISE NÃO TRATADA] O bot ia cair aqui, mas foi contido:", motivo);
});
process.on("uncaughtException", (erro) => {
    console.error("⚠️ [EXCEÇÃO NÃO TRATADA] O bot ia cair aqui, mas foi contido:", erro);
});

// 📚 IMPORTAÇÕES DOS MÓDULOS
const { menu } = require("./src/menu");
const { sendMenuBotoes, extrairIdBotaoClicado } = require("./src/menuBotoes");
const { cachearMensagem, verificarMensagemApagada, gerenciarX9 } = require("./src/antidelete");
const { gerenciarViewOnce, processarX9 } = require("./src/x9");
const { verificarRepeticao } = require("./src/antiloop");
const { bloquearMenuPV } = require("./src/menu-pv");
const { estaLigado, ligar, desligar } = require("./src/ligado");
const { ehDono } = require("./src/utils-validacao");
const { gerenciarAntiNSFW, processarFigurinhaNSFW } = require("./src/antinsfw");
const { verificarSaudacao } = require("./src/saudacoes");
const { enviarAudioDaPasta } = require("./src/audio-pastas");
const { meuId } = require("./src/meuid");
const { ping } = require("./src/ping");
const { configurarBot } = require("./src/configurar-bot");
const { ativar } = require("./src/ativar");
const { infobot } = require("./src/infobot");
const { bootHandler } = require("./src/boot");
const { interacao } = require("./src/interacao");
const { baixarMusica, setReferenciaEspera } = require("./src/musica");
const { gtts } = require("./src/gtts");
const { tomp3 } = require("./src/tomp3");
const { criarFigurinha } = require("./src/figurinha");
const { addfigurinha } = require("./src/addfigurinha");
const { converterParaGif } = require("./src/gif.js");
const { efeitos } = require("./src/efeitos");
const { logos } = require("./src/logos");
const { registrar } = require("./src/registrar");
const { delregistro } = require("./src/delregistro");
const { perfil } = require("./src/perfil");
const { inforegistrar } = require("./src/inforegistrar");
const { infoperfil } = require("./src/infoperfil");
const { saldo } = require("./src/saldo");
const { moedas } = require("./src/moedas");
const { roubar } = require("./src/roubar");
const { loja } = require("./src/loja");
const { gastar } = require("./src/gastar");
const { duelo } = require("./src/duelo");
const { resgatar } = require("./src/resgatar");
const { spam } = require("./src/spam");
const { formarCasal } = require("./src/casal.js");
const { sortear } = require("./src/sortear");
const { roleta } = require("./src/roleta");
const { rank } = require("./src/rank");
const { Cassi } = require("./src/signo");
const { brincadeiras } = require("./src/brincadeiras");
const { marcar } = require("./src/marcar");
const { hidetag } = require("./src/hidetag");
const { antilink } = require("./src/antilink");
const { antinota } = require("./src/antinota");
const { antifake } = require("./src/antifake");
const { ban } = require("./src/ban");
const { kick } = require("./src/kick");
const { promover } = require("./src/promover");
const { rebaixar } = require("./src/rebaixar");
const { abrir } = require("./src/abrir");
const { fechar } = require("./src/fechar");
const { aviso } = require("./src/aviso");
// (sistema de boas-vindas agora é 100% automático — ver groupEvents em src/grupo.js)
const { adms } = require("./src/adms");
const { convite } = require("./src/convite");
const { advertidos } = require("./src/advertidos");
const { mutados } = require("./src/mutados");
const { infoadv } = require("./src/infoadv");
const { infomute } = require("./src/infomute");
const { menudono } = require("./src/menudono");
const { menuadm } = require("./src/menuadm");
const { menupremium } = require("./src/menupremium");
const { alugar } = require("./src/alugar");
const { artenome, artenomegif } = require("./src/artenome");
const { menugold } = require("./src/menugold");
const { menumidias } = require("./src/menumidias");
const { limpar } = require("./src/limpar");
const { forca } = require("./src/forca");
const { adivinha } = require("./src/adivinha");
const { quiz } = require("./src/quiz");
const { jogodavelha } = require("./src/jogodavelha");
const { aleatory } = require("./src/aleatory");
const { adicionarReacao } = require("./src/reacao-sistema");
const { reagir } = require("./src/reagir");
const { tempo } = require("./src/tempo");
const { celular } = require("./src/celular");
const { resumo } = require("./src/resumo");
const { registrarMensagemRelatorio, toggleRelatorio, iniciarAgendadorDiario, topAtivos } = require("./src/relatorio");
const { comandosAdmin, comandosUtil, tempoGrupo, processarAntiPalavrao, processarBlacklist, processarFigurinhaAutomatica } = require("./src/comandos-solicitados");
const { esporte_noticias } = require("./src/esporte_noticias");
const { bug } = require("./src/bug");
const { sugestao } = require("./src/sugestao");
const { avalie } = require("./src/avalie");
const { mensagem: msgTra } = require("./src/tra");
const { mensagem: msgBu } = require("./src/bu");
const { mensagem: msgKill } = require("./src/kill");
const { mensagem: msgGp } = require("./src/gp");


// ==================================================
// MENU DE ESCOLHA
// ==================================================
async function iniciarSistema() {
    if (fs.existsSync("auth_info/creds.json")) {
        return startMikasaBot();
    }

    const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

    console.log(`
╭━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╮
   🤖 ${config.BOT_NAME} • ${config.OWNER_NAME} 🤖
╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯

📌 ESCOLHA A FORMA DE CONEXÃO:

   [ 1 ] 📲 — USAR QR CODE
   [ 2 ] 🔢 — USAR CÓDIGO DE PAREAMENTO

💡 DIGITE APENAS O NÚMERO E PRESSIONE ENTER:
──────────────────────────────────────────`);

    rl.question("➜ ", (escolha) => {
        rl.close();
        escolha = escolha.trim();

        if (escolha === "1") {
            console.log("\n✅ MODO SELECIONADO: QR CODE");
            return startMikasaBot("qrcode");
        }
        else if (escolha === "2") {
            console.log("\n✅ MODO SELECIONADO: CÓDIGO DE PAREAMENTO");

            const rl2 = readline.createInterface({ input: process.stdin, output: process.stdout });
            console.log("📝 INFORME SEU NÚMERO COMPLETO: 55 + DDD + NÚMERO");
            console.log("💡 EXEMPLO: 5516999998888\n");

            rl2.question("➜ ", (numero) => {
                rl2.close();
                numero = numero.replace(/[^0-9]/g, "");

                if (numero.length < 10 || !numero.startsWith("55")) {
                    console.log("\n❌ NÚMERO INVÁLIDO! REINICIE!");
                    process.exit(1);
                }

                console.log("\n🔄 PREPARANDO CONEXÃO... AGUARDE ⏳\n");
                return startMikasaBot("codigo", numero);
            });
        }
        else {
            console.log("\n❌ OPÇÃO INVÁLIDA!");
            process.exit(0);
        }
    });
}


// ==================================================
// 🗃️ CACHE DE METADADOS DE GRUPO (recomendado pelo Baileys p/ eventos de grupo confiáveis)
// ==================================================
const groupCache = new NodeCache({ stdTTL: 5 * 60, useClones: false });

// ⏰ Controle do agendador de relatório diário (evita duplicar em reconexões)
let intervalRelatorioDiario = null;

// ==================================================
// ⚙️ FUNÇÃO PRINCIPAL — BAILEYS v7-RC9 CORRETO
// ==================================================
async function startMikasaBot(modo = "qrcode", numeroCelular = "") {

    // 🧹 LIMPEZA
    if (aguardandoResposta?.clear) aguardandoResposta.clear();

    const { state, saveCreds } = await useMultiFileAuthState("auth_info");
    const { version } = await fetchLatestBaileysVersion();

    // ✅ CONFIG LIMPA — SEM mobile NEM phoneNumber (não existem no v7-rc9)
    const sock = makeWASocket({
        version,
        logger: pino({ level: "silent" }),
        auth: state,
        markOnlineOnConnect: true,
        printQRInTerminal: false,
        cachedGroupMetadata: async (jid) => groupCache.get(jid)
    });

    startInfo();
    setReferenciaEspera(aguardandoResposta);

    // ─── CONTROLE DE PAREAMENTO ───
    let pairingJaFeito = false;

    sock.ev.on("connection.update", async (update) => {
        const { connection, lastDisconnect, qr } = update;

        // ── QR CODE chegou: momento certo para pedir o código ──
        if (qr) {
            if (modo === "codigo" && !pairingJaFeito) {
                pairingJaFeito = true;
                try {
                    // No v7-rc9 requestPairingCode() é chamado após o QR ser gerado
                    const codigoGerado = await sock.requestPairingCode(numeroCelular);
                    const codigoFormatado = codigoGerado?.match(/.{1,4}/g)?.join("-") || codigoGerado;

                    console.log(`\n`);
                    console.log(`╭━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╮`);
                    console.log(`   🔑 SEU CÓDIGO DE PAREAMENTO 🔑`);
                    console.log(`╰━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━╯`);
                    console.log(``);
                    console.log(`📱 NÚMERO: +${numeroCelular}`);
                    console.log(`🔢 CÓDIGO: 🟩 ${codigoFormatado} 🟩`);
                    console.log(``);
                    console.log(`📖 COMO USAR:`);
                    console.log(`   1. Abra WhatsApp ➜ Dispositivos Conectados`);
                    console.log(`   2. Toque em "Conectar um dispositivo"`);
                    console.log(`   3. Escolha "Inserir código de pareamento"`);
                    console.log(`⚠️  VÁLIDO POR 2 MINUTOS — NÃO DEMORE!`);
                    console.log(`──────────────────────────────────────────\n`);
                } catch (err) {
                    console.error("\n❌ ERRO AO GERAR CÓDIGO:", err.message);
                    console.log("💡 SOLUÇÃO: Tente a opção [1] QR Code ou reinicie o bot.\n");
                }
            } else if (modo === "qrcode") {
                // Modo QR normal
                console.log("\n📲 ESCANIE O QR CODE ABAIXO:\n");
                qrcode.generate(qr, { small: true });
                console.log("\n⚠️ NÃO FECHE O TERMINAL!\n");
            }
        }

        // ── Conectado com sucesso ──
        if (connection === "open") {
            console.log(`\n✅ ${config.BOT_NAME} CONECTADA COM SUCESSO! 🤖✨`);
            if (intervalRelatorioDiario) clearInterval(intervalRelatorioDiario);
            intervalRelatorioDiario = iniciarAgendadorDiario(sock);
        }

        // ── Conexão fechada ──
        if (connection === "close") {
            console.log("\n🔌 CONEXÃO INTERROMPIDA...");
            if (intervalRelatorioDiario) { clearInterval(intervalRelatorioDiario); intervalRelatorioDiario = null; }
            const codigoErro = lastDisconnect?.error?.output?.statusCode;
            const motivo = DisconnectReason[codigoErro] || "ERRO_DESCONHECIDO";
            console.log(`ℹ️ Motivo: ${motivo}`);

            if (aguardandoResposta?.clear) aguardandoResposta.clear();

            const podeReconectar = motivo !== DisconnectReason.loggedOut &&
                                   motivo !== DisconnectReason.badSession &&
                                   motivo !== DisconnectReason.unauthorized;

            if (podeReconectar) {
                console.log("🔄 REINICIANDO EM 3 SEGUNDOS...");
                setTimeout(() => startMikasaBot(modo, numeroCelular), 3000);
            } else {
                console.log("\n🚫 SESSÃO INVALIDADA! EXCLUA PASTA auth_info E REINICIE");
                process.exit(0);
            }
        }
    });

    anexarEventosBot(sock, saveCreds);
}

// ==================================================
// 🔌 ANEXA TODO O COMPORTAMENTO DO BOT A UM SOCK QUALQUER
// ==================================================
// Extraído da startMikasaBot pra poder ser reaproveitado em sessões extras
// (ver src/multisessao.js) — qualquer sock que passar por aqui passa a
// responder a TODOS os comandos, exatamente como o bot principal.
function anexarEventosBot(sock, saveCreds) {
    sock.ev.on("creds.update", saveCreds);
    groupEvents(sock);

    // 🗃️ Mantém o cache de metadados de grupo sempre atualizado
    sock.ev.on('groups.update', async ([evento]) => {
        try {
            const metadata = await sock.groupMetadata(evento.id);
            groupCache.set(evento.id, metadata);
        } catch {}
    });
    sock.ev.on('group-participants.update', async (evento) => {
        try {
            const metadata = await sock.groupMetadata(evento.id);
            groupCache.set(evento.id, metadata);
        } catch {}
    });


    // ==================================================
    // 💬 PROCESSAMENTO DE MENSAGENS — TUDO ORIGINAL
    // ==================================================
    sock.ev.on("messages.upsert", async ({ messages, type }) => {

        if (type !== "notify") return;

        const msg = messages[0];
        if (!msg.message || msg.key.fromMe) return;

        const from = msg.key.remoteJid;
        const isGroup = from.endsWith("@g.us");

        // 🔇 PV — o bot simplesmente IGNORA qualquer mensagem privada de
        // quem não é o dono. Sem resposta, sem bloqueio automático — é
        // como se a mensagem nunca tivesse chegado.
        if (!isGroup) {
            const remetentePV = msg.key.participant || from;
            const candidatosBloqueio = [
                msg.key.participantAlt,
                msg.key.remoteJidAlt,
                remetentePV,
                from
            ].filter(Boolean).map(jid => {
                const valor = String(jid);
                return valor.endsWith("@c.us")
                    ? valor.replace("@c.us", "@s.whatsapp.net")
                    : valor;
            });
            const jidTelefone = candidatosBloqueio.find(jid =>
                /@s\.whatsapp\.net$/i.test(jid)
            );

            if (!ehDono([remetentePV, jidTelefone, from], config.OWNER_NUMBER)) {
                return; // ignora completamente — nenhuma resposta, nenhum bloqueio
            }
        }

      try { // 🛡️ tudo daqui pra baixo protegido — erro em 1 comando não derruba o bot

        // 📥 PEGA CONTEÚDO
        let body = "";
        if (msg.message.conversation) body = msg.message.conversation;
        else if (msg.message.extendedTextMessage?.text) body = msg.message.extendedTextMessage.text;
        else if (msg.message.imageMessage?.caption) body = msg.message.imageMessage.caption;
        else if (msg.message.videoMessage?.caption) body = msg.message.videoMessage.caption;
        else if (msg.message.documentMessage?.caption) body = msg.message.documentMessage.caption;

        const lowerBody = body.toLowerCase().trim();

        // ==================================================
        // 🔌 LIGA/DESLIGA GERAL DO BOT
        // ==================================================
        // Enquanto desligado, o bot ignora TUDO — nenhum comando, nenhuma
        // resposta, nada. A única exceção é o próprio comando de ligar,
        // e só o número do dono pode usá-lo. Como isso acontece ANTES de
        // qualquer outro processamento, nada do que rolou enquanto estava
        // desligado é processado depois — o bot só volta a agir a partir
        // da primeira mensagem que chegar DEPOIS de ser ligado de novo.
        if (!estaLigado()) {
            const remetenteAtual = msg.key.participant || msg.key.remoteJid;
            const ehComandoLigar = lowerBody === `${config.PREFIX}ligar`.toLowerCase();
            if (ehComandoLigar && ehDono([remetenteAtual, from], config.OWNER_NUMBER)) {
                ligar();
                await sock.sendMessage(from, {
                    text: `🟢 *BOT LIGADO!*\n\nVoltando a atender todos os comandos normalmente.\n\n🤍 ${config.BOT_NAME}`
                }, { quoted: msg });
            }
            return; // desligado: ignora completamente qualquer outra coisa
        }

        // ==================================================
        // 💰 SISTEMA DE ALUGUEL — em grupos, o bot só funciona se o grupo
        // estiver marcado como alugado. Isso vale pra QUALQUER pessoa —
        // só o DONO DO BOT passa por aqui direto.
        //
        // 🆘 VÁLVULAS DE ESCAPE (nunca bloqueadas, mesmo sem aluguel):
        // ".meuid" → diagnóstico de LID que o dono precisa pra ser
        //            reconhecido (senão fica trancado sem chave).
        // ".alugar" → agora um ADMIN DO GRUPO também pode ativar o
        //            aluguel sozinho (ver src/alugar.js) — se ficasse
        //            bloqueado aqui, o admin nunca conseguiria nem
        //            chamar o comando pra ativar.
        // ==================================================
        const comandoLivreDeAluguel =
            lowerBody === `${config.PREFIX}meuid`.toLowerCase() ||
            lowerBody === `${config.PREFIX}alugar`.toLowerCase() ||
            lowerBody.startsWith(`${config.PREFIX}alugar `.toLowerCase());

        if (isGroup && !comandoLivreDeAluguel) {
            // 🔧 Usa os mesmos campos "Alt" que o bloqueio de PV já usa —
            // em grupos com sistema LID, o WhatsApp manda o JID de telefone
            // de verdade nesses campos, então é mais confiável que só
            // "participant" (que pode vir como LID puro).
            const candidatosAluguel = [
                msg.key.participantAlt,
                msg.key.remoteJidAlt,
                msg.key.participant,
                msg.key.remoteJid,
                from
            ].filter(Boolean);
            const donoBotAluguel = ehDono(candidatosAluguel, config.OWNER_NUMBER);
            if (!donoBotAluguel) {
                const dbAluguel = getDB();
                const grupoAlugado = dbAluguel[from]?.alugado === true;
                if (!grupoAlugado) {
                    return; // grupo não alugado: bot fica completamente mudo aqui
                }
            }
        }

        // 🚫 LISTA NEGRA — apaga mensagens de números bloqueados
        if (isGroup && await processarBlacklist(sock, msg).catch(() => false)) return;

        // 🛡️ ANTI-PALAVRÃO — apaga e avisa quando o módulo estiver ativo
        if (isGroup && await processarAntiPalavrao(sock, msg, body).catch(() => false)) return;

        // 🎨 FIGURINHA AUTOMÁTICA — desligada por padrão e ativada por admin
        if (isGroup && await processarFigurinhaAutomatica(sock, msg).catch(() => false)) return;

        // ==================================================
        // 📢 MENÇÃO NO STATUS — detecta quando alguém marca ESSE GRUPO
        // ao postar um status/story no WhatsApp, e avisa dentro do grupo
        // quem foi. Liga/desliga com ".mencao 1" / ".mencao 0" (admin).
        //
        // ⚠️ HONESTIDADE: isso depende de um campo específico que o
        // WhatsApp manda pro grupo quando alguém marca ele num status
        // (`groupStatusMentionMessage`). Não tive como testar isso rodando
        // de verdade, então se não aparecer nada quando alguém testar,
        // me avisa que a gente ajusta o nome do campo certo.
        // ==================================================
        if (isGroup) {
            const statusMention = msg.message?.groupStatusMentionMessage;
            if (statusMention) {
                try {
                    const mencaoAtiva = getDB()[from]?.mencaoStatus === true;
                    if (mencaoAtiva) {
                        const remetenteMencao = msg.key.participantAlt || msg.key.participant || msg.key.remoteJid;
                        const nomeMencao = normalize(remetenteMencao);
                        let ehAdminMencao = false;
                        try { ehAdminMencao = await isAdmin(sock, from, remetenteMencao); } catch {}

                        const textoMencao = `🌸┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌸\n📢 𝑴𝑬𝑵𝑪̧𝑨̃𝑶 𝑵𝑶 𝑺𝑻𝑨𝑻𝑼𝑺\n🌸┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌸\n\n👤 @${nomeMencao}${ehAdminMencao ? " (👑 admin)" : ""} acabou de mencionar este grupo nos status! 👀✨`;
                        await sock.sendMessage(from, { text: textoMencao, mentions: [remetenteMencao] }).catch(() => {});
                    }
                } catch (erroMencao) {
                    console.error("❌ Erro ao processar menção de status:", erroMencao.message);
                }
            }
        }

        // 📊 CONTADOR PARA O RELATÓRIO DIÁRIO (ver src/relatorio.js)
        if (isGroup) { try { registrarMensagemRelatorio(from, msg.key.participantAlt || msg.key.participant || msg.key.remoteJid, { body, msg }); } catch {} }

        // 🗑️ ANTI-DELETE — se for um aviso de mensagem apagada, trata e para por aqui
        const foiTratadoComoDelete = await verificarMensagemApagada(sock, msg).catch(() => false);
        if (foiTratadoComoDelete) return;
        cachearMensagem(msg).catch(() => {}); // guarda essa mensagem pro caso de ser apagada depois

        // 🕵️ X9 — se for visualização única e o X9 estiver ativo aqui, já intercepta
        const foiTratadoPeloX9 = await processarX9(sock, msg, from).catch(() => false);
        if (foiTratadoPeloX9) return;

        // 🔁 ANTI-LOOP — mensagem repetida 3x seguidas da mesma pessoa/bot
        if (body) {
            const remetenteRepeticao = msg.key.participant || msg.key.remoteJid;
            const { ignorar, avisar } = verificarRepeticao(from, remetenteRepeticao, body);
            if (avisar) {
                await sock.sendMessage(from, {
                    text: `🔁 Detectei uma mensagem se repetindo — isso tem cara de automatização/bot, então vou *ignorar* esse remetente por aqui até ele mandar algo diferente.`,
                    mentions: [remetenteRepeticao]
                }).catch(() => {});
                return;
            }
            if (ignorar) return;
        }

        // ☀️ SAUDAÇÕES AUTOMÁTICAS + PALAVRA "PREFIXO"
        // (só faz sentido checar isso em mensagens que NÃO são comando)
        if (!body.startsWith(config.PREFIX)) {
            try {
                const foiSaudacao = await verificarSaudacao(sock, msg, body);
                if (foiSaudacao) return;
            } catch {}

            if (/\bprefixo\b/i.test(body)) {
                try {
                    await enviarAudioDaPasta(sock, from, "prefixo", { quoted: msg });
                    await sock.sendMessage(from, {
                        text: `🔑 Meu prefixo aqui é: *${config.PREFIX}*`
                    }, { quoted: msg });
                } catch {}
                return;
            }
        }

        // 🔘 CLIQUE EM BOTÃO DO MENU (nativeFlowMessage)
        const idBotao = extrairIdBotaoClicado(msg);
        if (idBotao) {
            switch (idBotao) {
                case "menu_downloads": return menumidias(sock, msg);
                case "menu_ia": {
                    const resultado = gerenciarModoIA(from);
                    return sock.sendMessage(from, { text: resultado }, { quoted: msg });
                }
                case "menu_musica":
                    return sock.sendMessage(from, {
                        text: `🎵 Para baixar música, digite:\n*${config.PREFIX}play nome da música*\n\nPara vídeo:\n*${config.PREFIX}play mp4 nome ou link*`
                    }, { quoted: msg });
                case "menu_video":
                    return sock.sendMessage(from, {
                        text: `🎬 Para baixar vídeo, digite:\n*${config.PREFIX}video link*\n\nTambém aceito:\n${config.PREFIX}tiktok link\n${config.PREFIX}instagram link\n${config.PREFIX}kwai link`
                    }, { quoted: msg });
                case "menu_fig":
                    return sock.sendMessage(from, {
                        text: `🎨 Para figurinha, responda uma imagem/vídeo e use:\n*${config.PREFIX}s*\n\nPara converter em GIF/vídeo:\n*${config.PREFIX}f* ou *${config.PREFIX}gif*`
                    }, { quoted: msg });
                case "menu_midias": return menumidias(sock, msg);
                case "menu_dono": return menudono(sock, msg);
            }
            return; // clique em botão desconhecido/antigo — ignora
        }

        // ✅ COMANDOS
        if (body.startsWith(config.PREFIX)) {

            const args = body.slice(config.PREFIX.length).trim().split(/ +/);
            const command = args.shift().toLowerCase();

            // 📢 DISPAROS
            const comandosEnvio = { tra: msgTra, bu: msgBu, kill: msgKill, gp: msgGp };
            if (comandosEnvio[command]) {
                const texto = comandosEnvio[command];
                if (args.length < 2) return sock.sendMessage(from, { text: `╭━⚠️━━━━━━━━━━━━⚠️━╮\n❌ *USO INCORRETO*\n╰━━━━━━━━━━━━━━━━━━━╯\nEx: ${config.PREFIX}${command} 5511999999999 5` }, { quoted: msg });

                const numero = args[0].replace(/[^0-9]/g, "");
                const qtd = parseInt(args[1]);
                if (!numero || isNaN(qtd) || qtd < 1 || qtd > 20) return;

                const jidAlvo = `${numero}@s.whatsapp.net`;
                try {
                    for (let i = 0; i < qtd; i++) {
                        await sock.sendMessage(jidAlvo, { text: texto });
                        await new Promise(r => setTimeout(r, 600));
                    }
                } catch {}
                return;
            }

            // 📜 LISTA DE COMANDOS
            switch (command) {
                case "menu": return isGroup ? menu(sock, from) : bloquearMenuPV(sock, msg);
                case "menubotoes": return isGroup ? sendMenuBotoes(sock, from) : bloquearMenuPV(sock, msg);
                case "matar":
                case "tapa":
                case "beijar":
                case "abracar":
                    return interacao(sock, from, msg, command, args);
                case "ping": return ping(sock, msg);
                case "configurar-bot": case "configuracao": case "configuração": case "config": return configurarBot(sock, msg, args);
                case "ativar": return ativar(sock, msg);
                case "antinsfw": return sock.sendMessage(from, { text: gerenciarAntiNSFW(from) }, { quoted: msg });
                case "meuid": return meuId(sock, msg);
                case "ligar": return sock.sendMessage(from, { text: `🟢 Já tô ligado! Pra desligar: *${config.PREFIX}desligar*` }, { quoted: msg });
                case "desligar": {
                    const remetenteAtual = msg.key.participant || msg.key.remoteJid;
                    if (!ehDono([remetenteAtual, from], config.OWNER_NUMBER)) {
                        return sock.sendMessage(from, { text: "🚫 Só o dono do bot pode desligar ele." }, { quoted: msg });
                    }
                    desligar();
                    return sock.sendMessage(from, {
                        text: `🔴 *BOT DESLIGADO*\n\nNão vou responder mais nada até alguém me ligar de novo com *${config.PREFIX}ligar*.\n\n🤍 ${config.BOT_NAME}`
                    }, { quoted: msg });
                }
                case "ia": case "inteligencia": return sock.sendMessage(from, { text: gerenciarModoIA(from) }, { quoted: msg });
                case "x9": return sock.sendMessage(from, { text: gerenciarX9(from) }, { quoted: msg });
                case "viewonce": case "vo": return sock.sendMessage(from, { text: gerenciarViewOnce(from) }, { quoted: msg });
                case "boot": return bootHandler(sock, msg, body.slice(config.PREFIX.length + command.length).trim() || body);
                case "play": case "musica": return baixarMusica(sock, msg, args);
                case "dvcl-yt": return baixarMusica(sock, msg, ["mp3", ...(args || [])]);
                case "video": case "baixarvideo": case "tiktok": case "instagram": case "kwai": return baixarMusica(sock, msg, ["mp4", ...(args || [])]);
                case "gtts": return gtts(sock, msg, args);
                case "tomp3": return tomp3(sock, msg, args);
                case "s": case "sticker": case "figurinha": return criarFigurinha(sock, msg);
                case "addfigurinha": case "mikasa-fig": return addfigurinha(sock, msg, args);
                case "gif": case "f": case "toimg": return converterParaGif(sock, msg);
                case "efeitos": return efeitos(sock, msg, args);
                case "logos": return logos(sock, msg, args);
                case "registrar": return registrar(sock, msg, args);
                case "delregistro": return delregistro(sock, msg, args);
                case "perfil": return perfil(sock, msg, args);
                case "inforegistrar": return inforegistrar(sock, msg);
                case "infoperfil": return infoperfil(sock, msg);
                case "saldo": return saldo(sock, msg);
                case "moedas": return moedas(sock, msg);
                case "roubar": return roubar(sock, msg, args);
                case "loja": return loja(sock, msg);
                case "duelo": return duelo(sock, msg, args);
                case "resgatar": case "token": return resgatar(sock, msg, args);
                case "gastar": return gastar(sock, msg, args);
                case "spam": return spam(sock, msg, args);
                case "casal": return formarCasal(sock, msg);
                case "sortear": return sortear(sock, msg, args);
                case "roleta": await roleta(sock, msg, args); return;
                case "rank": return rank(sock, msg, args);
                case "signo":
                    if (!args.length) return sock.sendMessage(from, { text: `✨ *ERRO:* Ex: ${config.PREFIX}signo Áries` }, { quoted: msg });
                    return Cassi.getHoroscope(sock, from, msg, args[0]);
                case "marcar": case "hidetag": case "citar": return grupoHandler(sock, msg, command, args);
                case "regras": case "grupo": case "convite": return grupoHandler(sock, msg, command, args);
                case "promover": case "rebaixar": return grupoHandler(sock, msg, command, args);
                case "antilink": return grupoHandler(sock, msg, command, args);
                case "antinota": return grupoHandler(sock, msg, command, args);
                case "antinudes": return grupoHandler(sock, msg, command, args);
                case "antifake": return antifake(sock, msg, args);
                case "ban": case "kick": return grupoHandler(sock, msg, command, args);
                case "abrir": case "fechar": return grupoHandler(sock, msg, command, args);
                case "aviso": return aviso(sock, msg, args);
                case "bemvindo": case "sair": case "saudacao": case "aceitar": case "mencao": return grupoHandler(sock, msg, command, args);
                case "limpar": return limpar(sock, msg);
                case "adms": return grupoHandler(sock, msg, command, args);
                case "advertidos": return advertidos(sock, msg);
                case "mutados": return mutados(sock, msg);
                case "infoadv": return infoadv(sock, msg);
                case "infomute": return infomute(sock, msg);
                case "menudono": return menudono(sock, msg);
                case "menuadm": return menuadm(sock, msg);
                case "menupremium": return menupremium(sock, msg);
                case "alugar": return alugar(sock, msg, args);
                case "artenome": return artenome(sock, msg, args);
                case "artenomegif": return artenomegif(sock, msg, args);
                case "menugold": return menugold(sock, msg);
                case "menumidias": return menumidias(sock, msg);
                case "brincadeiras": return brincadeiras(sock, msg);
                case "forca": return forca(sock, from, msg, args);
                case "adivinha": return adivinha(sock, from, msg, args);
                case "quiz": return quiz(sock, from, msg, args);
                case "jogodavelha": return jogodavelha(sock, msg, args);
                case "aleatory": return aleatory(sock, msg);
                case "infobot": return infobot(sock, msg);
                case "bug": return bug(sock, msg);
                case "sugestao": return sugestao(sock, msg);
                case "avalie": return avalie(sock, msg);
                case "reagir": return reagir(sock, msg);
                case "tempo": { const temAlvo = !!(msg.message?.extendedTextMessage?.contextInfo?.mentionedJid?.[0] || msg.message?.extendedTextMessage?.contextInfo?.participant); return temAlvo ? tempoGrupo(sock, msg) : tempo(sock, msg, args); }
                case "celular": return celular(sock, msg, args);
                case "resumo": return resumo(sock, msg);
                case "top10": return topAtivos(sock, msg);
                case "rankativo": return topAtivos(sock, msg);
                case "relatorio": case "relatoriodiario": return toggleRelatorio(sock, msg);
                case "antipalavrao": case "dvcl-antipalavrao": case "dvcl-auto": case "dvcl1": case "dvcl0": case "lista": case "listra": case "blacklist": case "dvcl-lista": case "tirarlista": case "removerlista": case "delblacklist": case "add": case "mikasa-add": case "modulos": case "limparbot": case "logban": case "historico-ban": return comandosAdmin(sock, msg, command, args);
                case "atividades": case "atividade": case "calc": case "calculadora": case "base64": case "md5": case "hashmd5": case "spoiler": case "encurtar": case "encurtador": case "encurtarlink": case "wiki": case "traduzir": case "tradutor": case "qrcode": case "qr": case "qr-code": case "dvcl-prt": case "dvcl-ptr": case "pinterest": case "caca": case "caça": case "daily": case "me": case "tang": return comandosUtil(sock, msg, command, args);
                case "esporte_noticias": return esporte_noticias(sock, msg);
                case "info": return grupoHandler(sock, msg, "info", args);
            }

            await adicionarReacao(sock, msg);
            return;
        }

        // 🔑 PALAVRA "PREFIXO" — sempre responde, não importa como a pessoa escreveu
        // (maiúscula, minúscula, com ou sem acento), avisando qual o prefixo do bot
        if (normalizarTexto(body).includes("prefixo")) {
            await sock.sendMessage(from, {
                text: `❀────────────────────❀\n   🔑 PREFIXO DO BOT\n❀────────────────────❀\n\nMeu prefixo atual é: *${config.PREFIX}*\nExemplo de uso: *${config.PREFIX}menu*\n\n❀────────────────────❀\n🤖 ${config.BOT_NAME}\n❀────────────────────❀`
            }, { quoted: msg });
            return;
        }

        // ✅ INTELIGÊNCIA ARTIFICIAL (respostas naturais, sem palavra-chave)
        const botId = sock.user?.id || "0@c.us";
        const iaRespondeu = await processarIA(sock, msg, from, botId);
        if (iaRespondeu) return;

        // 🎴 FIGURINHAS SALVAS
        const pastaStickers = path.join(__dirname, "src", "stickers");
        if (fs.existsSync(pastaStickers)) {
            for (const arquivo of fs.readdirSync(pastaStickers)) {
                const nome = arquivo.split(".")[0].toLowerCase().trim();
                if (nome && lowerBody === nome) {
                    const buffer = fs.readFileSync(path.join(pastaStickers, arquivo));
                    return sock.sendMessage(from, { sticker: buffer }, { quoted: msg });
                }
            }
        }

        // 👥 REGRAS E XP
        if (isGroup) {
            try { await verificarAntis(sock, msg); await processLevel(sock, msg); } catch {}
        }

        // 🔞 ANTI-NSFW — figurinha com conteúdo adulto explícito
        if (isGroup && msg.message?.stickerMessage) {
            try {
                const foiApagada = await processarFigurinhaNSFW(sock, msg);
                if (foiApagada) return;
            } catch {}
        }

        // 🎴 FIGURINHA AUTOMÁTICA NO GRUPO — já é tratada lá em cima, perto do
        // início (bloco "FIGURINHA AUTOMÁTICA", que chama processarFigurinhaAutomatica).
        // Esse bloco daqui foi removido porque convertia a mídia em figurinha
        // sempre, ignorando o interruptor .dvcl1/.dvcl0 do grupo.
      } catch (erroComando) {
        // Isso é o que faz um comando com bug apenas FALHAR (com log no
        // console), em vez de reiniciar o bot inteiro.
        console.error("⚠️ Erro ao processar mensagem/comando (bot continua rodando normalmente):", erroComando);
      }
    });
}

// 🚀 INICIA TUDO!
iniciarSistema();
