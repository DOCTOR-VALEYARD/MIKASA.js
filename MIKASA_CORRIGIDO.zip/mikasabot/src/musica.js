/* =================================================
   🎵 MIKASA BOT — MUSICA V6.7
   📁 musica.js
   👑 DOCTOR VALEYARD

   V6.7
   ✅ .play Artista -> escolhe uma música do artista
   ✅ .play Artista Música -> procura a música
   ✅ .play Música -> procura a música
   ✅ Busca vários resultados antes do download
   ✅ SOMENTE 1 download
   ✅ Retry automático trocando de cliente do YouTube (android/default/ios)
      se um estiver bloqueado (403 / "confirme que não é robô")
   ✅ Áudio enviado no formato ORIGINAL (m4a/webm/opus) — sem conversão
      pra MP3, que era a etapa mais lenta (ffmpeg recodificando tudo).
      O WhatsApp toca esses formatos direto, sem perda de qualidade.
   ✅ Vídeo e documento mantidos
   ✅ Card final mantido
================================================= */

const { exec } = require('child_process');
const fs = require('fs');
const path = require('path');
const https = require('https');
const axios = require('axios');

const config = require('../config');

const { criarCardMusica } =
    require('./cardGenerator');

const { enviarCardOuAnimado } =
    require('./card-envio');

const { buscarFotoContexto } =
    require('./foto-contexto');

// =================================================
// 🎵 CONFIGURAÇÃO
// =================================================

async function baixarTikTokDireto(url, destino) {
    const resposta = await axios.get("https://www.tikwm.com/api/", { params: { url }, timeout: 20000, headers: { "User-Agent": "Mozilla/5.0" } });
    const dados = resposta.data?.data || {};
    const urlVideo = dados.play || dados.wmplay || dados.hdplay;
    if (!urlVideo) throw new Error("TikTok não retornou uma URL de vídeo utilizável");
    const video = await axios.get(urlVideo, { responseType: "arraybuffer", timeout: 60000, headers: { "User-Agent": "Mozilla/5.0" } });
    fs.writeFileSync(destino, Buffer.from(video.data));
    return { titulo: dados.title || "TikTok" };
}

function comandoBase() {

    const extra =
        config.MUSICA?.ARGS_EXTRA
            ? ` ${config.MUSICA.ARGS_EXTRA}`
            : "";

    return `${
        config.MUSICA?.BINARIO || "yt-dlp"
    }${extra}`;
}

// =================================================
// 🔠 BOLD
// =================================================

function toBold(str) {

    const BASE_UPPER = 0x1D400;
    const BASE_LOWER = 0x1D41A;
    const BASE_DIGIT = 0x1D7CE;

    return String(str)
        .normalize('NFD')
        .split('')
        .map(ch => {

            const code =
                ch.charCodeAt(0);

            if (
                code >= 65 &&
                code <= 90
            ) {
                return String.fromCodePoint(
                    BASE_UPPER +
                    code - 65
                );
            }

            if (
                code >= 97 &&
                code <= 122
            ) {
                return String.fromCodePoint(
                    BASE_LOWER +
                    code - 97
                );
            }

            if (
                code >= 48 &&
                code <= 57
            ) {
                return String.fromCodePoint(
                    BASE_DIGIT +
                    code - 48
                );
            }

            return ch;

        })
        .join('');
}

// =================================================
// ⏱️ DURAÇÃO
// =================================================

function formatDuration(s) {

    if (
        isNaN(s) ||
        s < 0
    ) {
        return "00:00";
    }

    const m =
        Math.floor(s / 60);

    const r =
        Math.floor(s % 60);

    return (
        String(m).padStart(2, '0') +
        ":" +
        String(r).padStart(2, '0')
    );
}

// =================================================
// 👁️ VISUALIZAÇÕES
// =================================================

function formatViews(n) {

    if (
        !n ||
        isNaN(n)
    ) {
        return "—";
    }

    return Number(n)
        .toLocaleString('pt-BR');
}

// =================================================
// 📅 DATA
// =================================================

function formatUploadDate(dateStr) {

    if (
        !dateStr ||
        String(dateStr).length !== 8
    ) {
        return "—";
    }

    const ano =
        String(dateStr).slice(0, 4);

    const mes =
        String(dateStr).slice(4, 6);

    const dia =
        String(dateStr).slice(6, 8);

    return `${dia}/${mes}/${ano}`;
}

// =================================================
// 🕐 HORA
// =================================================

function formatUploadTime(timestamp) {

    if (!timestamp) {
        return null;
    }

    try {

        return new Date(
            timestamp * 1000
        ).toLocaleTimeString(
            'pt-BR',
            {
                hour: '2-digit',
                minute: '2-digit'
            }
        );

    } catch {

        return null;
    }
}

// =================================================
// 🖼️ IMAGEM
// =================================================

function baixarImagem(url) {

    return new Promise(
        (resolve, reject) => {

            if (!url) {
                return reject(
                    new Error(
                        "URL da imagem vazia"
                    )
                );
            }

            https.get(
                url,
                res => {

                    if (
                        res.statusCode !== 200
                    ) {
                        return reject(
                            new Error(
                                `HTTP ${res.statusCode}`
                            )
                        );
                    }

                    const chunks = [];

                    res.on(
                        'data',
                        chunk => {
                            chunks.push(chunk);
                        }
                    );

                    res.on(
                        'end',
                        () => {

                            resolve(
                                Buffer.concat(
                                    chunks
                                )
                            );

                        }
                    );

                }
            ).on(
                'error',
                reject
            );
        }
    );
}

// =================================================
// ⏱️ LIMITE PARA OPERAÇÕES AUXILIARES
// =================================================
// Evita que capa, foto de contexto ou metadados do grupo deixem o
// comando pendurado depois que o áudio já foi entregue.
function comTimeout(promessa, tempoMs, valorFallback = null) {
    return Promise.race([
        Promise.resolve(promessa).catch(() => valorFallback),
        new Promise(resolve => {
            setTimeout(() => resolve(valorFallback), tempoMs);
        })
    ]);
}

// =================================================
// ⚙️ EXEC
// =================================================

function execPromise(
    comando,
    timeoutMs
) {

    return new Promise(
        (resolve, reject) => {

            console.log(
                `▶️ Comando: ${comando}`
            );

            exec(
                comando,
                {
                    maxBuffer:
                        1024 * 1024 * 30,

                    timeout:
                        timeoutMs
                },

                (
                    err,
                    stdout,
                    stderr
                ) => {

                    if (err) {

                        const detalhe =
                            (
                                stderr ||
                                err.message ||
                                ""
                            )
                            .trim()
                            .split('\n')
                            .filter(Boolean)
                            .slice(-3)
                            .join(' | ')
                            .slice(0, 800);

                        return reject(
                            new Error(
                                detalhe ||
                                "Falha no comando."
                            )
                        );
                    }

                    resolve({
                        stdout:
                            stdout || "",

                        stderr:
                            stderr || ""
                    });
                }
            );
        }
    );
}

// =================================================
// 🧹 LIMPEZA
// =================================================

function limparArquivos(
    template
) {

    // Igual ao encontrarArquivo: limpa QUALQUER arquivo com esse nome de
    // template, seja qual for a extensão que o yt-dlp tenha usado —
    // assim não sobra lixo de tentativas que falharam no meio do caminho.
    const pasta =
        path.dirname(template);

    const prefixo =
        path.basename(template);

    let arquivos = [];

    try {
        arquivos =
            fs.readdirSync(pasta);
    } catch {
        return;
    }

    for (
        const nome of arquivos
    ) {

        if (
            !nome.startsWith(prefixo)
        ) continue;

        try {
            fs.unlinkSync(
                path.join(pasta, nome)
            );
        } catch {}
    }
}

// =================================================
// ✂️ GARANTE QUE SÓ VAI ÁUDIO (sem vídeo grudado)
// =================================================
//
// Alguns clientes do YouTube (o "android"/"ios" usados aqui pra driblar
// bloqueio) às vezes não expõem uma trilha de áudio separada — nesse
// caso o fallback de formato escolhido baixe o VÍDEO inteiro junto
// (muito mais pesado, é por isso que às vezes a música demora mais pra
// enviar: o arquivo é maior do que precisa). Aqui a gente confere se
// veio vídeo junto e, se vier, tira só o áudio com cópia direta (sem
// recodificar — é rápido) antes de mandar pro WhatsApp.
async function garantirSoAudio(caminho) {
    try {
        const { stdout } = await execPromise(
            `ffprobe -v error -select_streams v -show_entries stream=codec_type -of csv=p=0 "${caminho}"`,
            8000
        );

        if (!stdout || !stdout.trim()) {
            return caminho; // já é só áudio, nada a fazer
        }

        console.log("🎬 MUSICA — veio com vídeo grudado, extraindo só o áudio antes de enviar (fica bem mais leve/rápido)...");

        const destino = caminho.replace(/\.[^.]+$/, "") + "_so_audio.m4a";
        await execPromise(`ffmpeg -y -i "${caminho}" -vn -acodec copy "${destino}"`, 20000);

        if (fs.existsSync(destino) && fs.statSync(destino).size > 5000) {
            return destino;
        }

        return caminho;

    } catch (erroProbe) {
        // Se o ffprobe/ffmpeg falhar por qualquer motivo, segue com o
        // arquivo original — isso é só uma otimização, não pode travar
        // o envio da música.
        console.warn("⚠️ MUSICA — não consegui checar/separar o áudio do vídeo:", erroProbe.message);
        return caminho;
    }
}
// =================================================
// 🔎 ACHA ARQUIVO
// =================================================

function encontrarArquivo(
    template,
    modo
) {

    // Em vez de só procurar uma lista fixa de extensões (que pode não
    // bater com o container que aquele cliente específico do YouTube
    // devolveu), procura QUALQUER arquivo gerado com esse nome de
    // template, ignorando só os arquivos que sabemos que não são mídia
    // final (.part, .ytdl, .json, .description são sobras do yt-dlp).
    const pasta =
        path.dirname(template);

    const prefixo =
        path.basename(template);

    const IGNORAR = [
        '.part',
        '.ytdl',
        '.json',
        '.description',
        '.info.json',
        '.jpg',
        '.jpeg',
        '.png',
        '.webp',
        '.vtt',
        '.ass',
        '.srt'
    ];

    let arquivos = [];

    try {
        arquivos =
            fs.readdirSync(pasta);
    } catch {
        return null;
    }

    for (
        const nome of arquivos
    ) {

        if (
            !nome.startsWith(prefixo)
        ) continue;

        if (
            IGNORAR.some(
                ext => nome.endsWith(ext)
            )
        ) continue;

        const caminho =
            path.join(pasta, nome);

        try {

            if (
                fs.statSync(caminho).size >= 5000
            ) {

                return caminho;
            }

        } catch {}
    }

    return null;
}

// =================================================
// 🔠 RÓTULOS
// =================================================

const L = {

    erroSemBusca:
        toBold("ERRO — SEM BUSCA"),

    motivo:
        toBold("MOTIVO"),

    comoUsar:
        toBold("COMO USAR"),

    video:
        toBold("VÍDEO"),

    documento:
        toBold("DOCUMENTO"),

    erroDownload:
        toBold("ERRO NO DOWNLOAD"),

    busca:
        toBold("BUSCA"),

    solicitadoPor:
        toBold("SOLICITADO POR"),

    info:
        toBold("INFO"),

    musicaEncontrada:
        toBold("MÚSICA ENCONTRADA"),

    musica:
        toBold("MÚSICA"),

    cantor:
        toBold("CANTOR"),

    canal:
        toBold("CANAL"),

    visualizacoes:
        toBold("VISUALIZAÇÕES"),

    publicadoEm:
        toBold("PUBLICADO EM"),

    musicaEnviada:
        toBold("MÚSICA ENVIADA"),

    mikasaBot:
        toBold("MIKASA BOT")
};

const LINHA =
    "━━━━━━━━━━━━━━━━━━━━";

// =================================================
// CONTROLE DE REFERÊNCIA
// =================================================

let aguardandoReferencia = null;

exports.setReferenciaEspera =
    ref => {

        aguardandoReferencia =
            ref;
    };

// =================================================
// 🔗 RESOLVE LINK CURTO DO TIKTOK
// =================================================

function resolverIdentidadeSolicitante(msg) {
    const pushName = String(msg?.pushName || "").trim();
    const key = msg?.key || {};
    const candidatos = [
        key.participantAlt,
        key.remoteJidAlt,
        key.participant,
        key.remoteJid
    ].filter(Boolean);

    const jidNumero = candidatos.find(jid =>
        /@(s\.whatsapp\.net|c\.us)$/i.test(String(jid))
    );

    const numero = jidNumero
        ? String(jidNumero).split("@")[0].replace(/\D/g, "")
        : "";

    const nome = pushName || (numero ? `+${numero}` : "Usuário");
    const exibicao = numero && pushName
        ? `${pushName} (+${numero})`
        : nome;

    return {
        nome,
        exibicao,
        numero,
        jid: jidNumero || candidatos[0] || ""
    };
}

function resolverRedirect(url, tentativas = 0) {
    return new Promise((resolve, reject) => {
        if (tentativas > 5) return resolve(url);

        let req;
        try {
            req = https.get(url, {
                headers: {
                    "user-agent": "Mozilla/5.0 (Linux; Android 10) AppleWebKit/537.36 Chrome/120 Mobile Safari/537.36"
                }
            }, res => {
                const codigo = res.statusCode || 0;
                const destino = res.headers.location;
                res.resume();

                if (codigo >= 300 && codigo < 400 && destino) {
                    const proximo = new URL(destino, url).toString();
                    return resolverRedirect(proximo, tentativas + 1)
                        .then(resolve)
                        .catch(reject);
                }

                resolve(url);
            });
            req.on("error", () => resolve(url));
            req.setTimeout(12000, () => {
                req.destroy();
                resolve(url);
            });
        } catch {
            resolve(url);
        }
    });
}

// =================================================
// 🎵 COMANDO PRINCIPAL
// =================================================

exports.baixarMusica =
async function(
    sock,
    msg,
    args
) {

    const from =
        msg.key.remoteJid;

    const identidade =
        resolverIdentidadeSolicitante(msg);

    const remetente =
        identidade.jid ||
        msg.key.participant ||
        msg.key.remoteJid;

    const nomeSolicitante =
        identidade.nome;

    // A identificação do solicitante não aparece no texto do resultado.
    // O nome limpo é usado somente dentro da caixa do card de música.

    const marcacaoSolicitante =
        identidade.numero ||
        (remetente || "").split('@')[0];

    // =================================================
    // 🎬 MODO
    // =================================================

    let modo = "audio";

    let argsBusca =
        [...(args || [])];

    const primeiraPalavra =
        (
            argsBusca[0] ||
            ""
        ).toLowerCase();

    if (
        [
            "mp4",
            "video",
            "vídeo"
        ].includes(
            primeiraPalavra
        )
    ) {

        modo = "video";

        argsBusca.shift();

    } else if (
        [
            "doc",
            "documento"
        ].includes(
            primeiraPalavra
        )
    ) {

        modo = "doc";

        argsBusca.shift();
    }

    const busca =
        argsBusca
            .join(" ")
            .trim();

    // =================================================
    // ❌ SEM BUSCA
    // =================================================

    if (
        !busca ||
        busca.length < 2
    ) {

        return sock.sendMessage(
            from,
            {
                text:
`〔 ❌ ${L.erroSemBusca} 〕
『 ❌ ${L.motivo} 』
   └─ Você não digitou o nome de nada
${LINHA}
> 💡 ${L.comoUsar}
   └─ ${config.PREFIX}play nome da música
> 🎬 ${L.video}
   └─ ${config.PREFIX}play mp4 nome da música
> 📄 ${L.documento}
   └─ ${config.PREFIX}play doc nome da música
〔 🤖 ${L.mikasaBot} 〕
│
├─ 🤍 ${config.BOT_NAME || "Mikasa Bot"}
└─ 🌹 ${config.OWNER_NAME || "Doctor Valeyard"}
${LINHA}`
            },
            {
                quoted: msg
            }
        );
    }

    // Links de TikTok/Instagram/Kwai precisam ir diretamente ao yt-dlp.
    // Se forem enviados como ytsearch1, o yt-dlp pesquisa o texto do link.
    const linkEncontrado = busca.match(/https?:\/\/[^\s]+/i);
    const ehLinkDireto = Boolean(linkEncontrado);
    const linkLimpo = linkEncontrado
        ? linkEncontrado[0].replace(/[),.;]+$/, "")
        : null;

    // =================================================
    // 🎤 IDENTIFICA SE É SÓ ARTISTA
    // =================================================

    /*
     * Se o usuário colocou apenas uma expressão curta,
     * vamos tratar como artista/busca ampla.
     *
     * Exemplo:
     *
     * .play Adele
     * .play Hungria
     * .play Moleques
     *
     * O yt-dlp receberá uma busca musical ampliada.
     *
     * Se houver várias palavras:
     *
     * .play Hungria Amor e Fé
     *
     * será tratada como busca específica.
     */

    const palavras =
        busca
            .split(/\s+/)
            .filter(Boolean);

    const buscaSomenteArtista =
        palavras.length <= 2;

    // =================================================
    // 🔎 CONSULTA MUSICAL
    // =================================================

    let consulta;

    if (ehLinkDireto) {
        consulta = await resolverRedirect(linkLimpo);
    } else if (buscaSomenteArtista) {
        consulta = `${busca} música`;
    } else {
        consulta = busca;
    }

    // Escapa aspas para shell
    const consultaSegura =
        consulta.replace(
            /"/g,
            '\\"'
        );

    // =================================================
    // ⏳ AVISO
    // =================================================

    let aviso;

    try {

        aviso =
            await sock.sendMessage(
                from,
                {
                    text:
                        `🔍 Procurando *${busca}* e baixando... 🎵`
                },
                {
                    quoted: msg
                }
            );

    } catch {

        aviso = msg;
    }

    // =================================================
    // 🚀 BUSCA + DOWNLOAD EM UMA ÚNICA OPERAÇÃO
    // =================================================

    const id =
        `${Date.now()}_${Math.random()
            .toString(36)
            .slice(2, 8)}`;

    const template =
        path.join(
            __dirname,
            id
        );

    // Para nomes, busca e baixa o primeiro resultado no mesmo processo.
    // Para links, baixa a URL diretamente, sem pesquisa intermediária.
    const alvoBusca =
        ehLinkDireto
            ? consultaSegura
            : `ytsearch1:${consultaSegura}`;

    const ehTikTok =
        /(?:tiktok\.com|vt\.tiktok\.com)/i.test(consulta);

    // Instagram é bem mais instável/lento pra extrair que YouTube/TikTok
    // (rate limit e respostas mais demoradas) — por isso dá mais tempo e
    // mais tentativas só quando o link é de lá, em vez de aplicar isso
    // pra tudo (o que deixaria o resto mais lento à toa).
    const ehInstagram =
        /(?:instagram\.com|instagr\.am)/i.test(consulta);

    const socketTimeout = ehInstagram ? 20 : 10;
    const tentativasRede = ehInstagram ? 3 : 1;
    const timeoutExecMs = ehInstagram ? 90000 : 60000;

    const argumentosExtrator =
        ehLinkDireto
            ? (ehTikTok
                ? '--extractor-args "tiktok:app_name=musical_ly"'
                : '')
            : (modo === "audio"
                ? '--extractor-args "youtube:player_client=web,android,ios"'
                : '--extractor-args "youtube:player_client=android,ios"');

    // Mantém um objeto inicial para os fallbacks de metadados caso o
    // download falhe antes de devolver o JSON completo.
    let escolhido = {
        title: busca,
        uploader: "",
        channel: ""
    };

    try {

        // =================================================
        // 🎵 DOWNLOAD REAL — 1 ÚNICA VEZ
        // =================================================

        if (
            modo === "audio"
        ) {

            let resultadoDownload = null;
            let arquivoReal = null;
            let ultimoErroDownload = null;

            // =================================================
            // 🔁 DOWNLOAD — CLIENTES COMBINADOS NUMA SÓ CHAMADA
            // =================================================
            //
            // Antes: 2 processos separados (android sozinho, depois ios
            // sozinho), cada um refazendo a extração completa da página
            // do zero — isso é o que mais pesava no tempo total. Agora
            // é UMA chamada só, pedindo os dois clientes ao mesmo tempo
            // (`player_client=web,android,ios`) — o yt-dlp tenta primeiro
            // o cliente web, que costuma oferecer áudio puro, e mantém
            // Android/iOS como alternativas dentro do mesmo processo.
            //
            // ⚠️ Prefere "bestaudio" e só cai para "best" quando os clientes
            // combinados não expõem uma faixa de áudio separada. Nesse caso,
            // garantirSoAudio() remove o vídeo antes do envio. O último
            // recurso abaixo continua disponível se o comando inteiro falhar.
            const comandoDownload =
                `${comandoBase()} ` +
                `"${alvoBusca}" ` +
                `-f "bestaudio/best" ` +
                `--no-playlist ` +
                `${argumentosExtrator} ` +
                `--no-warnings ` +
                `--socket-timeout ${socketTimeout} ` +
                `--retries ${tentativasRede} ` +
                `--fragment-retries ${tentativasRede} ` +
                `--concurrent-fragments 8 ` +
                `--print-json ` +
                `-o "${template}.%(ext)s"`;

            try {

                resultadoDownload =
                    await execPromise(
                        comandoDownload,
                        timeoutExecMs
                    );

                arquivoReal =
                    encontrarArquivo(
                        template,
                        "audio"
                    );

                if (!arquivoReal) {
                    throw new Error(
                        "Download concluído, mas o arquivo de áudio não foi encontrado."
                    );
                }

                console.log(
                    "✅ MUSICA — download concluído (android+ios combinados)"
                );

            } catch (e) {

                ultimoErroDownload = e;

                console.error(
                    "❌ MUSICA — android+ios combinados falharam:",
                    e.message
                );

                limparArquivos(template);
            }

            // =================================================
            // 🆘 ÚLTIMO RECURSO — só entra se NENHUM cliente tinha
            // áudio puro disponível pra essa música específica (raro).
            // Usa "worst" (a PIOR qualidade de vídeo disponível) em vez
            // de "best" — já que a gente só vai aproveitar o áudio mesmo,
            // não faz sentido baixar em alta qualidade só pra descartar
            // o vídeo depois. O --extract-audio SEM forçar formato faz
            // o ffmpeg só separar (remux) o áudio, sem recodificar —
            // e como o vídeo agora é bem menor, fica bem mais rápido.
            if (!arquivoReal) {

                console.error(
                    "⚠️ MUSICA — nenhum cliente tinha áudio puro, tentando último recurso (extrair da menor qualidade disponível)..."
                );

                const comandoUltimoRecurso =
                    `${comandoBase()} ` +
                    `"${alvoBusca}" ` +
                    `-f "bestaudio/worst" ` +
                    `--extract-audio ` +
                    `--no-playlist ` +
                    `${argumentosExtrator} ` +
                    `--no-warnings ` +
                    `--socket-timeout ${socketTimeout} ` +
                    `--retries ${tentativasRede} ` +
                    `--fragment-retries ${tentativasRede} ` +
                    `--concurrent-fragments 8 ` +
                    `--print-json ` +
                    `-o "${template}.%(ext)s"`;

                try {

                    resultadoDownload =
                        await execPromise(
                            comandoUltimoRecurso,
                            timeoutExecMs
                        );

                    arquivoReal =
                        encontrarArquivo(
                            template,
                            "audio"
                        );

                    if (arquivoReal) {
                        console.log(
                            "✅ MUSICA — download concluído (último recurso)"
                        );
                    }

                } catch (e) {
                    ultimoErroDownload = e;
                    console.error(
                        "❌ MUSICA — último recurso também falhou:",
                        e.message
                    );
                    limparArquivos(template);
                }
            }

            // 🔁 Mesmo reforço do modo vídeo: Instagram falha bastante de
            // forma passageira, então tenta mais uma vez antes de desistir.
            if (!arquivoReal && ehInstagram) {
                console.warn("⚠️ MUSICA — Instagram falhou, tentando novamente em 2s...");
                await new Promise(r => setTimeout(r, 2000));
                limparArquivos(template);
                try {
                    resultadoDownload = await execPromise(comandoDownload, timeoutExecMs);
                    arquivoReal = encontrarArquivo(template, "audio");
                    if (arquivoReal) {
                        console.log("✅ MUSICA — Instagram concluído na 2ª tentativa");
                    }
                } catch (erroRetry) {
                    ultimoErroDownload = erroRetry;
                    console.error("❌ MUSICA — Instagram falhou de novo:", erroRetry.message);
                    limparArquivos(template);
                }
            }

            if (!arquivoReal) {

                throw ultimoErroDownload ||
                    new Error("Download concluído, mas o arquivo de áudio não foi encontrado.");
            }

            console.log(
                `📁 Áudio: ${arquivoReal}`
            );

            // ✂️ Se veio vídeo grudado (ver garantirSoAudio acima),
            // troca pro arquivo só-áudio antes de continuar.
            const inicioPreparacaoAudio = Date.now();
            const arquivoAntesSeparacao = arquivoReal;
            arquivoReal = await garantirSoAudio(arquivoReal);

            console.log(
                `⏱️ MUSICA — preparação do áudio concluída em ${((Date.now() - inicioPreparacaoAudio) / 1000).toFixed(1)}s` +
                (arquivoAntesSeparacao !== arquivoReal ? " (vídeo removido)" : " (áudio puro)")
            );

            // =================================================
            // 📦 JSON
            // =================================================
            //
            // Se o download veio da API externa (Vreden), não existe
            // saída do yt-dlp pra ler — nesse caso já pula direto pro
            // fallback abaixo, que usa os metadados da busca inicial.

            let info = null;

            if (resultadoDownload) {

                const linhas =
                    resultadoDownload.stdout
                        .trim()
                        .split('\n')
                        .filter(Boolean);

                for (
                    let i =
                        linhas.length - 1;
                    i >= 0;
                    i--
                ) {

                    try {

                        const obj =
                            JSON.parse(
                                linhas[i]
                            );

                        if (
                            obj &&
                            typeof obj ===
                                "object"
                        ) {

                            info = obj;
                            break;
                        }

                    } catch {}
                }
            }

            // =================================================
            // 📌 SE JSON NÃO EXISTIR
            // =================================================

            if (!info) {

                info = {

                    title:
                        escolhido.title,

                    uploader:
                        escolhido.uploader,

                    channel:
                        escolhido.channel,

                    duration:
                        0,

                    thumbnail:
                        null,

                    view_count:
                        0,

                    upload_date:
                        null,

                    timestamp:
                        null
                };
            }

            // =================================================
            // CONTINUA NA PARTE 2
            // =================================================

// =================================================
// 🎵 DADOS DA MÚSICA
// =================================================

const {
    title,
    duration,
    uploader,
    thumbnail,
    channel,
    view_count,
    upload_date,
    timestamp
} = info;

// =================================================
// 📖 LÊ ÁUDIO
// =================================================

const buffer =
    fs.readFileSync(
        arquivoReal
    );

const tamanho =
    fs.statSync(
        arquivoReal
    ).size;

if (
    tamanho < 5000
) {

    throw new Error(
        "O áudio está vazio ou incompleto."
    );
}

// =================================================
// 📝 NOME DO ARQUIVO
// =================================================

let tituloSeguro =
    (
        title ||
        escolhido.title ||
        busca ||
        "musica"
    )
    .replace(
        /[<>:"/\\|?*]/g,
        ''
    )
    .trim();

if (
    !tituloSeguro
) {
    tituloSeguro =
        "musica";
}

// A extensão real do que foi baixado (m4a/webm/opus) — sem conversão
// pra mp3, o WhatsApp toca esses formatos direto, sem perda de tempo
// com ffmpeg recodificando o áudio inteiro.
const extensaoBaixada =
    path.extname(arquivoReal) || ".m4a";

const mimetypeAudio =
    extensaoBaixada === '.webm'
        ? 'audio/webm'
        : extensaoBaixada === '.opus'
            ? 'audio/ogg; codecs=opus'
            : extensaoBaixada === '.mp3'
                ? 'audio/mpeg'
                : 'audio/mp4'; // m4a

const nomeArquivo =
    `${tituloSeguro}${extensaoBaixada}`;

// =================================================
// 📤 ENVIA ÁUDIO
// =================================================

console.log(
    `📤 Enviando áudio: ${nomeArquivo}`
);

// ⏱️ Medição real do tempo de envio — pra você conseguir ver no log
// exatamente quanto tempo é a extração/leitura (rápido, local) e quanto
// é o UPLOAD em si pro servidor do WhatsApp (rede, fora do nosso
// controle). Isso tira a dúvida sem eu ficar chutando onde o tempo vai.
const inicioEnvioAudio = Date.now();

await sock.sendMessage(
    from,
    {
        audio: buffer,

        mimetype:
            mimetypeAudio,

        ptt:
            false,

        fileName:
            nomeArquivo
    },
    {
        quoted: aviso
    }
);

console.log(
    `✅ MUSICA — mídia enviada: ${nomeArquivo} (upload real levou ${((Date.now() - inicioEnvioAudio) / 1000).toFixed(1)}s, ${(buffer.length / 1024 / 1024).toFixed(2)} MB)`
);

// =================================================
// 🗑️ APAGA TEMPORÁRIO
// =================================================

try {
    fs.unlinkSync(
        arquivoReal
    );
} catch {}

// =================================================
// 🖼️ CAPA + FOTO DE CONTEXTO + NOME DO GRUPO (em paralelo, mais rápido)
// =================================================

const ehGrupo = from.endsWith("@g.us");

const inicioComplementos = Date.now();

const [capaBuffer, fotoContextoBuffer, metaGrupo] = await Promise.all([
    comTimeout(baixarImagem(thumbnail), 5000, null),
    comTimeout(buscarFotoContexto(sock, from), 5000, null),
    ehGrupo
        ? comTimeout(sock.groupMetadata(from), 5000, null)
        : Promise.resolve(null)
]);

console.log(
    `⏱️ MUSICA — complementos do card concluídos em ${((Date.now() - inicioComplementos) / 1000).toFixed(1)}s`
);

const nomeGrupo = metaGrupo?.subject || null;

// =================================================
// 📅 DATA
// =================================================

const dataPublicacao =
    formatUploadDate(
        upload_date
    );

const horaPublicacao =
    formatUploadTime(
        timestamp
    );

const linhaData =
    horaPublicacao
        ? `${dataPublicacao} às ${horaPublicacao}`
        : dataPublicacao;

// =================================================
// 📝 CARD — agora TODOS os detalhes vêm dentro do card (nada de texto
// grandão junto). O texto da mensagem fica só marcando quem pediu.
// =================================================

const enviarCardEmSegundoPlano = async () => {
    const inicioCard = Date.now();

    try {
        await enviarCardOuAnimado(
            sock, from,
            (fundoBuffer) => criarCardMusica({
                capaBuffer,
                titulo: title || escolhido.title || busca,
                artista: uploader || channel || escolhido.uploader || "—",
                duracao: formatDuration(duration),
                fotoContextoBuffer,
                nomeSolicitante,
                fundoBuffer,
                nomeGrupo,
                visualizacoes: formatViews(view_count),
                dataPublicacao: linhaData,
                canal: channel || escolhido.channel || uploader || "—",
                resultadoPorArtista: buscaSomenteArtista
            }),
            {
                caption: marcacaoSolicitante ? `👤 @${marcacaoSolicitante}` : "",
                mentions: remetente ? [remetente] : []
            },
            msg
        );

        console.log(
            `⏱️ MUSICA — card enviado em ${((Date.now() - inicioCard) / 1000).toFixed(1)}s`
        );

    } catch (erroCard) {
        console.error(
            "❌ Erro no card:",
            erroCard.message
        );

        try {
            await sock.sendMessage(
                from,
                {
                    text:
                        `🎵 *${title || escolhido.title || busca}*\n👤 @${marcacaoSolicitante}`,
                    mentions:
                        remetente ? [remetente] : []
                }
            );
        } catch {}
    }
};

// O áudio já foi entregue. O card continua sem bloquear o término do comando.
void enviarCardEmSegundoPlano();

// =================================================
// 🎬 VÍDEO / DOCUMENTO
// =================================================

} else {

    let resultadoDownload = null;
    let arquivoReal = null;
    let ultimoErroDownloadVideo = null;

    // 🔁 Mesma otimização do áudio: os dois clientes numa chamada só,
    // em vez de dois processos separados repetindo a extração.
    const comandoDownload =
        `${comandoBase()} ` +
        `"${alvoBusca}" ` +
        `-f "best[ext=mp4]/best" ` +
        `--no-playlist ` +
        `${argumentosExtrator} ` +
        `--no-warnings ` +
        `--socket-timeout ${socketTimeout} ` +
        `--retries ${tentativasRede} ` +
        `--fragment-retries ${tentativasRede} ` +
        `--concurrent-fragments 8 ` +
        `--print-json ` +
        `-o "${template}.%(ext)s"`;

    try {

        resultadoDownload =
            await execPromise(
                comandoDownload,
                timeoutExecMs
            );

        arquivoReal =
            encontrarArquivo(
                template,
                modo
            );

        if (!arquivoReal) {
            throw new Error(
                "O vídeo foi baixado, mas o arquivo não foi encontrado."
            );
        }

        console.log(
            "✅ MUSICA (vídeo) — download concluído (android+ios combinados)"
        );

    } catch (e) {

        ultimoErroDownloadVideo = e;

        console.error(
            "❌ MUSICA (vídeo) — android+ios combinados falharam:",
            e.message
        );

        limparArquivos(template);

        // Fallback direto para TikTok: alguns links atuais falham no yt-dlp
        // com "Unable to extract universal data for rehydration".
        if (ehTikTok && linkLimpo) {
            try {
                const destinoTikTok = `${template}.mp4`;
                const dadosTikTok = await baixarTikTokDireto(linkLimpo, destinoTikTok);
                arquivoReal = destinoTikTok;
                escolhido.title = dadosTikTok.titulo;
                console.log("✅ TikTok — download concluído pelo fallback direto");
            } catch (erroTikTok) {
                ultimoErroDownloadVideo = erroTikTok;
                console.error("❌ TikTok — fallback direto também falhou:", erroTikTok.message);
            }
        }

        // 🔁 Instagram falha bastante de forma passageira (rate limit /
        // resposta lenta do servidor deles). Antes de desistir, espera um
        // pouco e tenta essa mesma chamada mais uma vez — resolve a
        // maioria dos "às vezes dá erro" sem precisar o usuário mandar
        // o comando de novo.
        if (!arquivoReal && ehInstagram) {
            console.warn("⚠️ MUSICA (vídeo) — Instagram falhou, tentando novamente em 2s...");
            await new Promise(r => setTimeout(r, 2000));
            limparArquivos(template);
            try {
                resultadoDownload = await execPromise(comandoDownload, timeoutExecMs);
                arquivoReal = encontrarArquivo(template, modo);
                if (arquivoReal) {
                    console.log("✅ MUSICA (vídeo) — Instagram concluído na 2ª tentativa");
                }
            } catch (erroRetry) {
                ultimoErroDownloadVideo = erroRetry;
                console.error("❌ MUSICA (vídeo) — Instagram falhou de novo:", erroRetry.message);
                limparArquivos(template);
            }
        }
    }

    if (!arquivoReal) {

        throw ultimoErroDownloadVideo ||
            new Error("O vídeo foi baixado, mas o arquivo não foi encontrado.");
    }

    const buffer =
        fs.readFileSync(
            arquivoReal
        );

    const tituloVideo =
        (
            escolhido.title ||
            busca ||
            "video"
        )
        .replace(
            /[<>:"/\\|?*]/g,
            ''
        )
        .trim();

    const nomeVideo =
        `${tituloVideo}.mp4`;

    if (
        modo === "video"
    ) {

        await sock.sendMessage(
            from,
            {
                video:
                    buffer,

                mimetype:
                    "video/mp4",

                fileName:
                    nomeVideo
            },
            {
                quoted: aviso
            }
        );

    } else {

        await sock.sendMessage(
            from,
            {
                document:
                    buffer,

                mimetype:
                    "video/mp4",

                fileName:
                    nomeVideo
            },
            {
                quoted: aviso
            }
        );
    }

    try {
        fs.unlinkSync(
            arquivoReal
        );
    } catch {}
}

// =================================================
// ❌ ERRO
// =================================================

} catch (err) {

    console.error(
        "❌ MUSICA ERRO:",
        err.message
    );

    limparArquivos(
        template
    );

    try {

        await sock.sendMessage(
            from,
            {
                text:
`〔 ❌ ${L.erroDownload} 〕
『 🔍 ${L.busca} 』
   └─ ${busca}
${LINHA}
> 💬 ${L.motivo}
   └─ ${err.message}
> ℹ️ ${L.info}
   └─ Tente novamente com outro nome.
〔 🤖 ${L.mikasaBot} 〕
│
├─ 🤍 ${config.BOT_NAME || "Mikasa Bot"}
└─ 🌹 ${config.OWNER_NAME || "Doctor Valeyard"}
${LINHA}`,
                mentions:
                    [remetente]
            },
            {
                quoted: msg
            }
        );

    } catch {}
}

};