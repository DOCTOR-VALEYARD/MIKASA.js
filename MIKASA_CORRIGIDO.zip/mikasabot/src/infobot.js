// src/infobot.js - INFO DO BOT PUXANDO DA CONFIG
const config = require("../config");

async function infobot(sock, msg) {
    const from = msg.key.remoteJid;
    
    const resp = `

〔 🤖 𝐈𝐍𝐅𝐎 𝐃𝐎 𝐁𝐎𝐓 〕
『 📋 𝐈𝐃𝐄𝐍𝐓𝐈𝐃𝐀𝐃𝐄  』
└─ 📛 Nome: ${config.BOT_NAME}
└─ 👑 Criadora: ${config.OWNER_NAME}
└─ 📞 Contato: ${config.OWNER_NUMBER}
└─ 📌 Prefixo: ${config.PREFIX}
└─ 📊 Versão: ${config.VERSION}
━━━━━━━━━━━━
«💻 𝐓𝐄𝐂𝐍𝐎𝐋𝐎𝐆𝐈𝐀
└─ Linguagem: Node.js
└─ Framework: Baileys
└─ Status: Online ✅
━━━━━━━━━━━━
⚡ 𝐒𝐈𝐒𝐓𝐄𝐌𝐀
└─ 🎯 Comandos: 101+
└─ 🌟 Status: Todos funcionando
━━━━━━━━━━━━
🤍 ${config.BOT_NAME}
🌹 ${config.OWNER_NAME}
━━━━━━━━━━━━»
`;

    await sock.sendMessage(from, { text: resp }, { quoted: msg });
}

module.exports = { infobot };
