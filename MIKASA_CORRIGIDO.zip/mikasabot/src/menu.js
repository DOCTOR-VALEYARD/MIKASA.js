// src/menu.js - MENU COM SUPORTE A FOTO/VÍDEO E ÁUDIO
const config = require("../config");
const fs = require("fs");
const path = require("path");
const { criarCardMenu } = require("./cardGenerator");
const { buscarFotoContexto } = require("./foto-contexto");
const { enviarAudioDaPasta } = require("./audio-pastas");

function lerDB() {
    const dbPath = path.join(__dirname, "../database/botconfig.json");
    if (!fs.existsSync(path.dirname(dbPath))) {
        fs.mkdirSync(path.dirname(dbPath), { recursive: true });
    }
    if (!fs.existsSync(dbPath)) {
        return {
            PREFIX: config.PREFIX,
            BOT_NAME: config.BOT_NAME,
            OWNER_NAME: config.OWNER_NAME,
            BOT_AUDIO: null,
            BOT_PHOTO: null
        };
    }
    return JSON.parse(fs.readFileSync(dbPath, "utf8"));
}

async function menu(sock, from) {
  try {
    const db = lerDB();
    const prefix = db.PREFIX || config.PREFIX || "/";
    const botName = db.BOT_NAME || config.BOT_NAME || "BOT";
    const ownerName = db.OWNER_NAME || config.OWNER_NAME || "Desconhecida";

    // 🔊 ÁUDIO DO MENU — agora puxa aleatoriamente de src/audios/menu/
    // (pode colocar quantos áudios quiser lá, sempre toca um diferente).
    // Se a pasta estiver vazia, cai no áudio único configurado pelo painel
    // (.configurar-bot), mantendo compatibilidade com quem já usava isso.
    let audioDoMenuEnviado = false;
    try {
        audioDoMenuEnviado = await enviarAudioDaPasta(sock, from, "menu");
    } catch (e) {
        console.log("Áudio da pasta 'menu' indisponível, tentando áudio configurado...");
    }

    if (!audioDoMenuEnviado && db.BOT_AUDIO && fs.existsSync(db.BOT_AUDIO)) {
        try {
            const audioBuffer = fs.readFileSync(db.BOT_AUDIO);
            await sock.sendMessage(from, { audio: audioBuffer, mimetype: "audio/mp4" });
        } catch (e) {
            console.log("Áudio não encontrado, pulando...");
        }
    }

    const text = `🌸┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌸
✨ 『 ${botName} 』✨
🌸┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌸

👑 ${ownerName}
🤖 ${botName}
💡 ${prefix}ping • ${prefix}ativar

🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
   ⚙️ 𝑪𝑶𝑵𝑭𝑰𝑮𝑺
🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
🌸 ${prefix}ping
🌸 ${prefix}configurar-bot
🌸 ${prefix}ativar
🌸 ${prefix}ia / inteligencia 🧠✨
🌸 ${prefix}bemvindo
🌸 ${prefix}aceitar
🌸 ${prefix}mencao

🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
   💻 𝑴𝑬𝑵𝑼𝑺
🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
🌸 ${prefix}menudono
🌸 ${prefix}menuadm
🌸 ${prefix}menupremium
🌸 ${prefix}menugold
🌸 ${prefix}menumidias
🌸 ${prefix}efeitos
🌸 ${prefix}logos
🌸 ${prefix}brincadeiras

🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
   👥 𝑴𝑬𝑴𝑩𝑹𝑶𝑺
🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
🌸 ${prefix}registrar
🌸 ${prefix}delregistro
🌸 ${prefix}perfil
🌸 ${prefix}inforegistrar
🌸 ${prefix}infoperfil
🌸 ${prefix}advertidos
🌸 ${prefix}mutados
🌸 ${prefix}infoadv
🌸 ${prefix}infomute
🌸 ${prefix}infobot
🌸 ${prefix}bug
🌸 ${prefix}sugestao
🌸 ${prefix}avalie
🌸 ${prefix}reagir
🌸 ${prefix}adms
🌸 ${prefix}convite
🌸 ${prefix}forca
🌸 ${prefix}adivinha
🌸 ${prefix}quiz
🌸 ${prefix}jogodavelha
🌸 ${prefix}aleatory
🌸 ${prefix}resumo

🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
   📚 𝑰𝑵𝑭𝑶𝑺
🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
🌸 ${prefix}rank
🌸 ${prefix}tabela
🌸 ${prefix}rankativo
🌸 ${prefix}rankinativos
🌸 ${prefix}atividades
🌸 ${prefix}moedas
🌸 ${prefix}esporte_noticias
🌸 ${prefix}celular (ex: Xiaomi)
🌸 ${prefix}tempo (cidade)

🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
   ⚡ 𝑪𝑶𝑴𝑨𝑵𝑫𝑶𝑺
🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
🌸 ${prefix}gtts (idioma+texto)
🌸 ${prefix}artenome (nome na foto)
🌸 ${prefix}artenomegif (nome animado na foto)
🌸 ${prefix}tomp3
🌸 ${prefix}gif / f / toimg
🌸 ${prefix}s / sticker / figurinha
🌸 ${prefix}roubar
🌸 ${prefix}signo
🌸 ${prefix}casal
🌸 ${prefix}saldo
🌸 ${prefix}loja
🌸 ${prefix}duelo
🌸 ${prefix}roleta
🌸 ${prefix}play / musica
🌸 ${prefix}sortear
🌸 ${prefix}spam
🌸 ${prefix}resgatar

💐┈┈┈┈┈┈┈┈┈┈┈┈┈┈💐
   ✨ 𝑺𝑻𝑨𝑻𝑼𝑺
💐┈┈┈┈┈┈┈┈┈┈┈┈┈┈💐
🌷 ${botName}
🌷 • 𝘖𝘕𝘓𝘐𝘕𝘌 ✅`;

    // Mídia do menu SEMPRE vem direto de src/menu.png (ou menu.mp4 pra vídeo),
    // não depende mais do botconfig.json — assim nunca fica "sem achar a foto"
    // mesmo que ela exista fisicamente na pasta.
    const caminhoFotoMenu = path.join(__dirname, "menu.png");
    const caminhoVideoMenu = path.join(__dirname, "menu.mp4");
    const ehVideo = fs.existsSync(caminhoVideoMenu);

    if (ehVideo) {
        const mediaBuffer = fs.readFileSync(caminhoVideoMenu);
        // 🎞️ Se a mídia salva veio de um GIF (BOT_PHOTO_GIF), manda com
        // gifPlayback pra tocar em loop igual gif, em vez de vídeo comum.
        await sock.sendMessage(from, {
            video: mediaBuffer,
            caption: text,
            mimetype: "video/mp4",
            gifPlayback: db.BOT_PHOTO_GIF === true
        });
    } else {
        let fotoBuffer = null;
        if (fs.existsSync(caminhoFotoMenu)) {
            try {
                fotoBuffer = fs.readFileSync(caminhoFotoMenu);
                console.log(`✅ menu.png encontrado (${fotoBuffer.length} bytes) em: ${caminhoFotoMenu}`);
            } catch (erroLeitura) {
                console.error(`❌ menu.png existe mas não consegui LER o arquivo em ${caminhoFotoMenu}:`, erroLeitura.message);
                fotoBuffer = null;
            }
        } else {
            console.error(`❌ menu.png NÃO EXISTE nesse caminho: ${caminhoFotoMenu}`);
        }

        try {
            // 📸 foto de quem chamou (grupo, ou a própria pessoa no PV)
            const fotoContextoBuffer = await buscarFotoContexto(sock, from);
            const card = await criarCardMenu({ fotoBuffer, botName, ownerName, fotoContextoBuffer });
            await sock.sendMessage(from, { image: card, caption: text });
        } catch (erroCard) {
            console.error("❌ Erro ao gerar card do menu:", erroCard);
            await sock.sendMessage(from, { text }); // fallback só em texto se o card falhar
        }
    }

  } catch (error) {
    console.error("❌ ERRO AO ENVIAR MENU:", error);
    await sock.sendMessage(from, { text: "😥 Erro ao gerar o menu." });
  }
}

module.exports = { menu };

