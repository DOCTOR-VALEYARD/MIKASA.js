/* =================================================
   📸 MIKASA BOT — FOTO DE CONTEXTO (pra usar nos cards)
   📁 Arquivo: foto-contexto.js

   Busca a foto que deve aparecer no cantinho de QUALQUER card:
   - Se o comando foi chamado dentro de um GRUPO -> foto do grupo
   - Se foi chamado no PV -> foto de perfil da própria pessoa
   Como "from" já é o JID certo em ambos os casos (grupo ou pessoa),
   é só pedir a foto de perfil dele mesmo — funciona pros dois.
================================================= */

const { baixarBuffer } = require("./cardGenerator");

async function buscarFotoContexto(sock, from) {
    try {
        const url = await sock.profilePictureUrl(from, "image");
        return await baixarBuffer(url);
    } catch {
        return null; // sem foto (grupo/pessoa sem foto definida) — os cards já lidam bem com isso
    }
}

module.exports = { buscarFotoContexto };
