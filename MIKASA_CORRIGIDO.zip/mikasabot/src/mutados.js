const config = require("../config");
async function mutados(sock, msg) {
    const from = msg.key.remoteJid;
    const resp = `
╭─「 🔇 *MUTADOS* 」
│
│ 📋 Lista de mutados: Vazio
│
│ 💡 Ninguém foi silenciado ainda
╰───────────────────────────`;
    await sock.sendMessage(from, { text: resp }, { quoted: msg });
}
module.exports = { mutados };
