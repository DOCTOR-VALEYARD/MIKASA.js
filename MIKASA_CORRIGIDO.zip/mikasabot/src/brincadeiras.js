const config = require("../config");
async function brincadeiras(sock, msg) {
    const from = msg.key.remoteJid;
    const resp = `
┅┄┅┄『 ✦ 』┄┅┄┅┄
『 ✦ 』${config.BOT_NAME}『 ✦ 』
┅┄┅┄『 ✦ 』┄┅┄┅┄

  🎭 BRINCADEIRAS 🎭

┅┄┅┄『 ✦ 』┄┅┄┅┄
『 ✦ 』 ${config.PREFIX}tapa @user
『 ✦ 』 ${config.PREFIX}matar @user
『 ✦ 』 ${config.PREFIX}beijar @user
『 ✦ 』 ${config.PREFIX}abracar @user
┅┄┅┄『 ✦ 』┄┅┄┅┄
😂 Diversão garantida!`;
    await sock.sendMessage(from, { text: resp }, { quoted: msg });
}
module.exports = { brincadeiras };
