const fs = require("fs");
const path = require("path");
const config = require("../config");
const { criarCardPerfil, baixarBuffer } = require("./cardGenerator");
const { enviarCardOuAnimado } = require("./card-envio");
const { buscarFotoContexto } = require("./foto-contexto");
const { chamarIA } = require("./mikasa-ia");

const dbPath = path.join(__dirname, "../database/usuarios.json");

// 📚 LEITURA DO BANCO
function lerUsuarios() {
    if (!fs.existsSync(path.dirname(dbPath))) {
        fs.mkdirSync(path.dirname(dbPath), { recursive: true });
    }
    if (!fs.existsSync(dbPath)) {
        return {};
    }
    return JSON.parse(fs.readFileSync(dbPath, "utf8"));
}

// 💾 SALVAR DADOS
function salvarUsuarios(dados) {
    fs.writeFileSync(dbPath, JSON.stringify(dados, null, 2), "utf8");
}

// 🎖️ CLASSIFICAÇÃO POR NÍVEL
function calcularPatente(nivel) {
    if (nivel >= 25) return "🏆 LENDÁRIO";
    if (nivel >= 18) return "🥇 DIAMANTE";
    if (nivel >= 12) return "🥈 OURO";
    if (nivel >= 7) return "🥉 PRATA";
    if (nivel >= 3) return "🔵 BRONZE";
    return "⚪ INICIANTE";
}

// 🧠 Comentário curto gerado pela IA sobre o desempenho da pessoa.
// Se a IA falhar ou estiver desligada, cai num comentário padrão (sem travar o comando).
async function gerarComentarioIA({ nomeAlvo, nivel, patente, moedas, vitorias, derrotas }) {
    const resumoDados = `Jogador: ${nomeAlvo}. Nível ${nivel} (patente ${patente}). ` +
        `${moedas} moedas, ${vitorias} vitórias e ${derrotas} derrotas em jogos do bot.`;

    const resposta = await chamarIA(
        [
            {
                role: "system",
                content: "Você escreve um comentário BEM curto (uma frase só, no máximo 18 palavras), " +
                    "descontraído e em português do Brasil, comentando o desempenho de alguém num bot de " +
                    "WhatsApp com base nos dados que a pessoa te der. Não repita os números crus, seja natural."
            },
            { role: "user", content: resumoDados }
        ],
        config.AI_MODEL
    );

    if (resposta) return resposta.replace(/^"|"$/g, "");

    // fallback caso a IA esteja fora do ar
    if (vitorias > derrotas) return "Tá mandando bem, continue assim! 🔥";
    if (derrotas > vitorias) return "Bora virar esse jogo, dá pra melhorar! 💪";
    return "Todo mundo começa de algum lugar, bora evoluir! ✨";
}

async function perfil(sock, msg, args) {
    const from = msg.key.remoteJid;
    const remetente = msg.key.participant || msg.key.remoteJid;
    const banco = lerUsuarios();

    // 👤 VERIFICA SE VAI VER O PRÓPRIO OU DE OUTRO
    let usuarioAlvo = remetente;
    let nomeAlvo = msg.pushName || "Usuário";

    // Se responder mensagem ou mencionar, pega o alvo
    if (msg.message?.extendedTextMessage?.contextInfo?.participant) {
        usuarioAlvo = msg.message.extendedTextMessage.contextInfo.participant;
    } else if (args[0]?.includes("@")) {
        usuarioAlvo = args[0].replace(/[^0-9@.]/g, "");
    }

    // 📄 DADOS DO USUÁRIO
    if (!banco[usuarioAlvo]) {
        return sock.sendMessage(from, {
            text: `┅┄┅┄『 ✦ 』┄┅┄┅┄
 ⚠️ *USUÁRIO NÃO ENCONTRADO*
┅┄┅┄『 ✦ 』┄┅┄┅┄
Esse usuário ainda não se cadastrou.
Use: ${config.PREFIX}registrar
┅┄┅┄『 ✦ 』┄┅┄┅┄`
        }, { quoted: msg });
    }

    const dados = banco[usuarioAlvo];
    const nivel = dados.nivel || 1;
    const exp = dados.xp || 0;
    const moedas = dados.ouro || 0;
    const vitorias = dados.vitorias || 0;
    const derrotas = dados.derrotas || 0;
    const nomeExibicao = usuarioAlvo.split("@")[0];

    // 📏 CÁLCULO PARA PRÓXIMO NÍVEL
    const expNecessario = nivel * 100;
    const patente = calcularPatente(nivel);

    // 🖼️ Busca a foto de perfil da pessoa (o card mostra o número se não tiver foto)
    let fotoBuffer = null;
    try {
        const fotoUrl = await sock.profilePictureUrl(usuarioAlvo, "image");
        fotoBuffer = await baixarBuffer(fotoUrl);
    } catch {
        fotoBuffer = null;
    }

    // 🧠 Comentário gerado pela IA sobre o desempenho da pessoa
    const comentarioIA = await gerarComentarioIA({
        nomeAlvo: dados.nome || nomeAlvo, nivel, patente, moedas, vitorias, derrotas
    });

    const textoFallback = `🪪 @${nomeExibicao}\n${comentarioIA}\n⭐ Nível: ${nivel} • ${patente}\n💸 ${Number(moedas).toLocaleString("pt-BR")}   ✅ ${vitorias}   ❌ ${derrotas}`;

    try {
        // 📸 foto de quem chamou o comando (grupo, ou a própria pessoa no PV)
        const fotoContextoBuffer = await buscarFotoContexto(sock, from);

        await enviarCardOuAnimado(sock, from, (fundoBuffer) => criarCardPerfil({
            fotoBuffer,
            nomeUsuario: nomeExibicao,
            patente,
            nivel,
            exp,
            expNecessario,
            moedas,
            vitorias,
            derrotas,
            fotoContextoBuffer,
            fundoBuffer,
            comentario: comentarioIA
        }), { caption: `👤 @${nomeExibicao}`, mentions: [usuarioAlvo] }, msg);
    } catch (erroCard) {
        console.error("❌ Erro ao gerar card de perfil:", erroCard);
        // fallback: garante que a informação chega mesmo se o card falhar
        await sock.sendMessage(from, {
            text: textoFallback,
            mentions: [usuarioAlvo]
        }, { quoted: msg });
    }
}

module.exports = { perfil, lerUsuarios, salvarUsuarios };
