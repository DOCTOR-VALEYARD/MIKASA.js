// src/menuBotoes.js — MENU COM BOTÕES (nativeFlowMessage / quick_reply)
//
// ⚠️ AVISO IMPORTANTE: botões interativos (nativeFlowMessage) usam um
// recurso NÃO OFICIAL do WhatsApp (a Meta restringe isso fora da API
// Business oficial). Dependendo da versão do WhatsApp da pessoa, o botão
// pode não aparecer ou o clique pode não ser entregue ao bot. Por isso,
// SEMPRE deixamos um jeito de digitar como alternativa (fallback) — nunca
// dependa 100% dos botões funcionando pra todo mundo.
const config = require("../config");

async function sendMenuBotoes(sock, jid) {
  await sock.sendMessage(jid, {
    text: `👾 *MENU PRINCIPAL — ${config.BOT_NAME}*\nEscolha uma opção abaixo ou digite ${config.PREFIX}menu pra ver tudo em texto:`,
    footer: `${config.BOT_NAME}-${config.VERSION} • Sistema`,
    interactiveMessage: {
      header: {
        title: "Painel do Bot",
        subtitle: "Selecione uma ação",
      },
      body: {
        text: "Sistema de comandos disponível",
      },
      footer: {
        text: config.BOT_NAME,
      },
      nativeFlowMessage: {
        buttons: [
          {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
              display_text: "📥 Downloads",
              id: "menu_downloads",
            }),
          },
          {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
              display_text: "🤖 IA",
              id: "menu_ia",
            }),
          },
          {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
              display_text: "🎵 Música",
              id: "menu_musica",
            }),
          },
          {
            name: "quick_reply",
            buttonParamsJson: JSON.stringify({
              display_text: "👤 Dono",
              id: "menu_dono",
            }),
          },
        ],
      },
    },
  });
}

// ── Extrai o "id" de um clique de botão (nativeFlow), se houver ──
function extrairIdBotaoClicado(msg) {
  try {
    const paramsJson = msg.message?.interactiveResponseMessage?.nativeFlowResponseMessage?.paramsJson;
    if (!paramsJson) return null;
    const dados = JSON.parse(paramsJson);
    return dados.id || null;
  } catch {
    return null;
  }
}

module.exports = { sendMenuBotoes, extrairIdBotaoClicado };
