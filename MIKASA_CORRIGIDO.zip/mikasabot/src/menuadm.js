// src/menuadm.js
const config = require("../config");
const fs = require("fs");
const path = require("path");


// ═══════════════════════════════════════════════════════════════
// 🛡️ MENU ADMINISTRATIVO
// ═══════════════════════════════════════════════════════════════

async function menuadm(sock, msg) {

    const from =
        msg?.key?.remoteJid;

    if (!from) {
        return;
    }


    // 🔐 Somente administradores podem abrir o painel administrativo.
    try {
        const meta = await sock.groupMetadata(from);
        const autor = msg.key.participant || msg.key.remoteJid;
        const admin = meta.participants.some(p => (p.id === autor || p.lid === autor) && p.admin);
        if (!admin) return sock.sendMessage(from, { text: "❌ O menu administrativo é exclusivo para administradores." }, { quoted: msg });
    } catch {
        return sock.sendMessage(from, { text: "❌ Não consegui verificar sua permissão de administrador." }, { quoted: msg });
    }

    // ═════════════════════════════════════════════════════════════
    // 🖼️ IMAGEM DO MENU
    // ═════════════════════════════════════════════════════════════

    const caminhoImagem =
        path.join(
            __dirname,
            "menu.png"
        );


    // ═════════════════════════════════════════════════════════════
    // 📋 MENU
    // ═════════════════════════════════════════════════════════════

    const resposta = `🌸┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌸
🛡️ 𝑴𝑬𝑵𝑼 𝑨𝑫𝑴𝑰𝑵𝑰𝑺𝑻𝑹𝑨𝑻𝑰𝑽𝑶
🌸┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌸
🔐 Área exclusiva para administradores

🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
   📊 𝑹𝑬𝑺𝑼𝑴𝑶 𝑬 𝑨𝑻𝑰𝑽𝑰𝑫𝑨𝑫𝑬
🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
🌸 ${config.PREFIX}resumo — tudo que rolou hoje
🌸 ${config.PREFIX}atividades — atividade dos membros
🌸 ${config.PREFIX}top10 / rankativo — ranking de interação
🌸 ${config.PREFIX}tempo — tempo no grupo
🌸 ${config.PREFIX}relatorio — resumo automático on/off

🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
   ⚔️ 𝑮𝑬𝑹𝑬𝑵𝑪𝑰𝑨𝑴𝑬𝑵𝑻𝑶 𝑫𝑶 𝑮𝑹𝑼𝑷𝑶
🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
🌸 ${config.PREFIX}ban / kick
🌸 ${config.PREFIX}promover / rebaixar
🌸 ${config.PREFIX}aviso
🌸 ${config.PREFIX}marcar / ${config.PREFIX}hidetag
🌸 ${config.PREFIX}citar
🌸 ${config.PREFIX}sair
🌸 ${config.PREFIX}abrir / fechar
🌸 ${config.PREFIX}alugar 1/0 — liga/desliga o bot neste grupo

🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
   🔒 𝑺𝑬𝑮𝑼𝑹𝑨𝑵𝑪̧𝑨 𝑬 𝑨𝑼𝑻𝑶𝑴𝑨𝑪̧𝑶̃𝑬𝑺
🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
🌸 ${config.PREFIX}antilink / ${config.PREFIX}antinota
🌸 ${config.PREFIX}antifake / ${config.PREFIX}antipalavrao
🌸 ${config.PREFIX}antispam on/off
🌸 ${config.PREFIX}antiflood on/off
🌸 ${config.PREFIX}dvcl-auto on/off — figurinha automática
🌸 ${config.PREFIX}dvcl1 — liga a figurinha automática
🌸 ${config.PREFIX}dvcl0 — desliga a figurinha automática
🌸 ${config.PREFIX}bemvindo 1/0 — boas-vindas e saída
🌸 ${config.PREFIX}aceitar 1/0 — aceitar solicitação automático
🌸 ${config.PREFIX}mencao 1/0 — avisa menção deste grupo em status
🌸 ${config.PREFIX}saudacao on/off — boas-vindas (mensagem simples)
🌸 ${config.PREFIX}blacklist / ${config.PREFIX}lista
🌸 ${config.PREFIX}limparbot
🌸 ${config.PREFIX}ativar / desativar

🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
   🧰 𝑭𝑬𝑹𝑹𝑨𝑴𝑬𝑵𝑻𝑨𝑺 𝑬 𝑪𝑶𝑴𝑨𝑵𝑫𝑶𝑺
🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
🌸 ${config.PREFIX}add número — adiciona membro
🌸 ${config.PREFIX}lista número — lista/adiciona blacklist
🌸 ${config.PREFIX}tirarlista número — remove da blacklist
🌸 ${config.PREFIX}logban — histórico de remoções
🌸 ${config.PREFIX}modulos — mostra módulos ativos
🌸 ${config.PREFIX}calc expressão — calcula
🌸 ${config.PREFIX}wiki termo — pesquisa termo
🌸 ${config.PREFIX}encurtar link — encurta link
🌸 ${config.PREFIX}traduzir idioma texto — traduz
🌸 ${config.PREFIX}base64 codificar texto — codifica/decodifica
🌸 ${config.PREFIX}md5 texto — gera hash
🌸 ${config.PREFIX}spoiler texto — oculta texto
🌸 ${config.PREFIX}qrcode texto/link — cria QR Code
🌸 ${config.PREFIX}me — mostra seu perfil
🌸 ${config.PREFIX}adms — lista administradores

💐┈┈┈┈┈┈┈┈┈┈┈┈┈┈💐
   ⚡ 𝑨𝑫𝑴𝑰𝑵 𝑪𝑶𝑵𝑻𝑹𝑶𝑳
💐┈┈┈┈┈┈┈┈┈┈┈┈┈┈💐
🌷 Sistema: ${config.BOT_NAME}
🌷 Responsável: ${config.OWNER_NAME}
🌷 Acesso: Administrativo
🌷 Status: 𝘖𝘱𝘦𝘳𝘢𝘤𝘪𝘰𝘯𝘢𝘭 🟢`;


    // ═════════════════════════════════════════════════════════════
    // 📤 ENVIO
    // ═════════════════════════════════════════════════════════════

    try {

        if (fs.existsSync(caminhoImagem)) {

            const bufferImagem =
                fs.readFileSync(
                    caminhoImagem
                );


            await sock.sendMessage(
                from,
                {
                    image: bufferImagem,
                    caption: resposta
                },
                {
                    quoted: msg
                }
            );

            return;
        }


        // ─────────────────────────────────────────────────────────
        // ⚠️ FALLBACK SEM IMAGEM
        // ─────────────────────────────────────────────────────────

        await sock.sendMessage(
            from,
            {
                text:
                    `${resposta}\n\n` +
                    `⚠️ *Imagem do menu não localizada.*`
            },
            {
                quoted: msg
            }
        );

    } catch (erro) {

        console.error(
            "❌ Erro ao enviar menu administrativo:",
            erro
        );
    }
}


// ═══════════════════════════════════════════════════════════════
// 📦 EXPORTAÇÃO
// ═══════════════════════════════════════════════════════════════

module.exports = {
    menuadm
};