const config = require("../config");
const { getDB, saveDB } = require("./grupo-db");
const { ehDono } = require("./utils-validacao");
const { isAdmin } = require("./grupo");

async function alugar(sock, msg, args) {
    const from = msg.key.remoteJid;
    const isGroup = from.endsWith("@g.us");
    const remetente = msg.key.participant || msg.key.remoteJid;
    const donoBot = ehDono([remetente, msg.key.participantAlt, from], config.OWNER_NUMBER);

    // ──────────────────────────────────────────────────────────────
    // 💰 O DONO DO BOT ou um ADMIN DO GRUPO podem ativar/desativar o
    // aluguel — e só faz sentido dentro de um grupo (é o grupo que
    // fica alugado ou não).
    // Ex: .alugar 1  → ativa o bot nesse grupo
    //     .alugar 0  → desativa o bot nesse grupo
    // ──────────────────────────────────────────────────────────────
    const userAdmin = isGroup && !donoBot ? await isAdmin(sock, from, remetente).catch(() => false) : false;

    if (isGroup && (donoBot || userAdmin)) {
        const argumento = String(args?.[0] || "").toLowerCase();
        const ligarPalavras = ["1", "on", "ativar", "ativado"];
        const desligarPalavras = ["0", "off", "desativar", "desativado"];

        if (ligarPalavras.includes(argumento) || desligarPalavras.includes(argumento)) {
            const novoEstado = ligarPalavras.includes(argumento);
            const db = getDB();
            if (!db[from]) db[from] = {};
            db[from].alugado = novoEstado;
            saveDB(db);

            const mensagem = novoEstado
                ? `✅ *GRUPO ALUGADO* ✅\n\n💰 O bot agora está liberado pra funcionar normalmente neste grupo.\n\n🤍 ${config.BOT_NAME}`
                : `❌ *ALUGUEL ENCERRADO* ❌\n\n💰 O bot foi desativado neste grupo — nenhum comando vai funcionar aqui até ser alugado de novo (nem para administradores).\n\n🤍 ${config.BOT_NAME}`;

            return sock.sendMessage(from, { text: mensagem }, { quoted: msg });
        }

        // usou ".alugar" sem argumento válido dentro de um grupo — mostra status + instrução
        const db = getDB();
        const estadoAtual = db[from]?.alugado === true;
        const mensagemStatus = `
╭─── ❀ ───
💰 SISTEMA DE ALUGUEL
╰─── ❀ ───

📊 Este grupo está: ${estadoAtual ? "🟢 ALUGADO" : "🔴 NÃO ALUGADO"}

❀ Use:
${config.PREFIX}alugar 1  → ativa o bot aqui
${config.PREFIX}alugar 0  → desativa o bot aqui

❀────────────────────❀
🤍 ${config.BOT_NAME}
❀────────────────────❀`;
        return sock.sendMessage(from, { text: mensagemStatus }, { quoted: msg });
    }

    // ──────────────────────────────────────────────────────────────
    // Qualquer outra pessoa (ou uso fora de grupo): mensagem de
    // divulgação de sempre, sem mexer em nada.
    // ──────────────────────────────────────────────────────────────
    const resp = `💼 *ALUGAR ${config.BOT_NAME}*\n\nInteressado em alugar este bot?\n\n📞 Contato: ${config.OWNER_NUMBER}\n👑 Criadora: ${config.OWNER_NAME}\n\nEntre em contato para mais informações!`;
    await sock.sendMessage(from, { text: resp }, { quoted: msg });
}

module.exports = { alugar };
