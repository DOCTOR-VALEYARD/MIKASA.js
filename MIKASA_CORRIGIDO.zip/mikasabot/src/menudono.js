// src/menudono.js
const config = require("../config");
const fs = require("fs");
const path = require("path");

async function menudono(sock, msg) {
    const from = msg.key.remoteJid;
    const caminhoImagem = path.join(__dirname, "menu.png"); // ✅ Pega direto da pasta src/

    // ✅ LAYOUT NOVO — MESMO PADRÃO FLORAL DO MENU PRINCIPAL
    const resposta = `🌸┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌸
✨ 『 ${config.BOT_NAME} 』✨
🌸┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌸

🔐 Comandos Exclusivos: ${config.OWNER_NAME}

🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
   💻 𝑴𝑰́𝑫𝑰𝑨 & 𝑭𝑬𝑹𝑹𝑨𝑴𝑬𝑵𝑻𝑨𝑺
🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
🌸 ${config.PREFIX}play [nome]
🌸 ${config.PREFIX}s / sticker
🌸 ${config.PREFIX}f / gif
🌸 ${config.PREFIX}toimg

🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
   💰 𝑺𝑰𝑺𝑻𝑬𝑴𝑨 𝑬𝑪𝑶𝑵𝑶̂𝑴𝑰𝑪𝑶
🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
🌸 ${config.PREFIX}saldo
🌸 ${config.PREFIX}roubar @user
🌸 ${config.PREFIX}loja
🌸 ${config.PREFIX}gastar

🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
   🎮 𝑫𝑰𝑽𝑬𝑹𝑺𝑨̃𝑶 & 𝑱𝑶𝑮𝑶𝑺
🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
🌸 ${config.PREFIX}forca
🌸 ${config.PREFIX}adivinha
🌸 ${config.PREFIX}quiz
🌸 ${config.PREFIX}duelo @user
🌸 ${config.PREFIX}roleta

🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
   ⚙️ 𝑪𝑶𝑵𝑻𝑹𝑶𝑳𝑬 𝑮𝑬𝑹𝑨𝑳
🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
🌸 ${config.PREFIX}ativar
🌸 ${config.PREFIX}desativar
🌸 ${config.PREFIX}configurar

💐┈┈┈┈┈┈┈┈┈┈┈┈┈┈💐
🌷 Plataforma: ${config.BOT_NAME}
🌷 Sistema: ${config.BOT_NAME}
🌷 Acesso: Administrador / Dono
💐┈┈┈┈┈┈┈┈┈┈┈┈┈┈💐`;

    // ✅ VERIFICA SE A FOTO EXISTE — SE TIVER ENVIA COM IMAGEM, SE NÃO ENVIA SÓ TEXTO SEM DAR ERRO
    if (fs.existsSync(caminhoImagem)) {
        const bufferImagem = fs.readFileSync(caminhoImagem);
        await sock.sendMessage(from, {
            image: bufferImagem,
            caption: resposta
        }, { quoted: msg });
    } else {
        // Aviso leve se faltar a imagem — não quebra nada
        const semImagem = resposta + `\n\n⚠️ *Aviso:* Imagem do menu não encontrada!`;
        await sock.sendMessage(from, { text: semImagem }, { quoted: msg });
    }
}

module.exports = { menudono };

