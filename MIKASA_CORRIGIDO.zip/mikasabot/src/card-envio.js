/* =================================================
   🎬 ENVIO DE CARD — ESTÁTICO OU ANIMADO
   📁 Arquivo: card-envio.js
   Centraliza a decisão: se o fundo configurado (.configurar-bot fundo)
   for vídeo/gif, o card é remontado quadro a quadro e enviado como
   vídeo (roda em loop). Se o fundo for imagem (ou não tiver fundo
   animado configurado), continua exatamente como antes: imagem parada.
   ================================================= */

const { estaFundoAnimado, gerarCardAnimadoComFundo } = require("./cardGenerator");

/**
 * @param {*} sock
 * @param {string} from
 * @param {(fundoBuffer?: Buffer) => Promise<Buffer>} gerarCard — gera o PNG do card; recebe um fundoBuffer quando está montando a versão animada
 * @param {object} opcoesEnvio — demais campos da mensagem (caption, mentions, etc)
 * @param {object} [msg] — mensagem original, pra responder com {quoted}
 * @param {(jid: string, conteudo: object) => Promise<any>} [enviarFn] — opcional: função customizada de envio
 *   (ex: com retentativa). Se não passar, usa sock.sendMessage(from, conteudo, {quoted}) como sempre.
 */
async function enviarCardOuAnimado(sock, from, gerarCard, opcoesEnvio, msg, enviarFn) {
    const quoted = msg ? { quoted: msg } : undefined;
    const enviar = enviarFn || ((jid, conteudo) => sock.sendMessage(jid, conteudo, quoted));

    if (estaFundoAnimado()) {
        try {
            const video = await gerarCardAnimadoComFundo((fundoBuffer) => gerarCard(fundoBuffer));
            if (video) {
                return await enviar(from, { video, gifPlayback: true, ...opcoesEnvio });
            }
        } catch (erro) {
            console.error("❌ Erro ao gerar card animado, caindo pro card estático:", erro.message);
        }
    }

    const card = await gerarCard();
    return await enviar(from, { image: card, ...opcoesEnvio });
}

module.exports = { enviarCardOuAnimado };
