
/* =================================================
   📊 SISTEMA DE NÍVEL, XP E MOEDAS
   📁 Arquivo: level.js
   🤖 ${config.BOT_NAME} • ${config.OWNER_NAME}
================================================= */

const fs = require("fs");
const path = require("path");
const config = require("../config");

const {
    criarCardLevelUp,
    baixarBuffer
} = require("./cardGenerator");

const { enviarCardOuAnimado } = require("./card-envio");

const {
    buscarFotoContexto
} = require("./foto-contexto");


// ═══════════════════════════════════════════════════════════════
// 📂 CONFIGURAÇÃO DO BANCO
// ═══════════════════════════════════════════════════════════════

const DB_DIR = path.join(__dirname, "..", "database");
const DB_PATH = path.join(DB_DIR, "usuarios.json");


// Garante que a pasta database exista
function garantirBanco() {
    if (!fs.existsSync(DB_DIR)) {
        fs.mkdirSync(DB_DIR, {
            recursive: true
        });
    }
}


// ═══════════════════════════════════════════════════════════════
// 📥 CARREGAR BANCO DE DADOS
// ═══════════════════════════════════════════════════════════════

function loadDB() {

    garantirBanco();

    if (!fs.existsSync(DB_PATH)) {
        return {};
    }

    try {

        const conteudo = fs.readFileSync(
            DB_PATH,
            "utf8"
        ).trim();

        if (!conteudo) {
            return {};
        }

        const dados = JSON.parse(conteudo);

        if (
            typeof dados !== "object" ||
            Array.isArray(dados) ||
            dados === null
        ) {
            console.warn(
                "⚠️ Banco inválido. Criando banco vazio."
            );

            return {};
        }

        return dados;

    } catch (erro) {

        console.error(
            "❌ Erro ao carregar usuarios.json:",
            erro
        );

        return {};
    }
}


// ═══════════════════════════════════════════════════════════════
// 💾 SALVAR BANCO DE DADOS
// ═══════════════════════════════════════════════════════════════

function saveDB(dados) {

    garantirBanco();

    const arquivoTemporario =
        `${DB_PATH}.tmp`;

    try {

        const conteudo =
            JSON.stringify(
                dados,
                null,
                2
            );

        // Escreve primeiro em arquivo temporário.
        // Isso reduz o risco de destruir o banco
        // caso o processo seja interrompido durante a escrita.
        fs.writeFileSync(
            arquivoTemporario,
            conteudo,
            "utf8"
        );

        fs.renameSync(
            arquivoTemporario,
            DB_PATH
        );

    } catch (erro) {

        console.error(
            "❌ Erro ao salvar usuarios.json:",
            erro
        );

        if (
            fs.existsSync(
                arquivoTemporario
            )
        ) {
            try {
                fs.unlinkSync(
                    arquivoTemporario
                );
            } catch {}
        }

        throw erro;
    }
}


// ═══════════════════════════════════════════════════════════════
// 👤 CRIAR / GARANTIR USUÁRIO
// ═══════════════════════════════════════════════════════════════

function garantirUsuario(
    db,
    usuarioId,
    nome = "Viajante"
) {

    if (!db[usuarioId]) {

        db[usuarioId] = {
            nivel: 1,
            xp: 0,
            ouro: 0,
            nome,
            ultimaAtividade: Date.now()
        };

        return db[usuarioId];
    }


    // Corrige possíveis dados antigos/incompletos
    if (
        typeof db[usuarioId].nivel !== "number" ||
        db[usuarioId].nivel < 1
    ) {
        db[usuarioId].nivel = 1;
    }

    if (
        typeof db[usuarioId].xp !== "number" ||
        db[usuarioId].xp < 0
    ) {
        db[usuarioId].xp = 0;
    }

    if (
        typeof db[usuarioId].ouro !== "number" ||
        db[usuarioId].ouro < 0
    ) {
        db[usuarioId].ouro = 0;
    }

    if (!db[usuarioId].nome) {
        db[usuarioId].nome = nome;
    }

    return db[usuarioId];
}


// ═══════════════════════════════════════════════════════════════
// 🎲 XP ALEATÓRIO
// ═══════════════════════════════════════════════════════════════

function gerarXP() {

    // Entre 5 e 15 XP
    return Math.floor(
        Math.random() * 11
    ) + 5;
}


// ═══════════════════════════════════════════════════════════════
// 🆙 PROCESSAMENTO DE LEVEL
// ═══════════════════════════════════════════════════════════════

async function processLevel(sock, msg) {

    try {

        // ───────────────────────────────────────────────────────
        // 🚫 IGNORA MENSAGENS SEM PARTICIPANTE
        // ───────────────────────────────────────────────────────

        if (!msg?.key?.participant) {
            return;
        }


        // ───────────────────────────────────────────────────────
        // 📝 EXTRAI TEXTO
        // ───────────────────────────────────────────────────────

        const textoMensagem =
            msg.message?.conversation ||
            msg.message?.extendedTextMessage?.text ||
            "";


        if (!textoMensagem) {
            return;
        }


        // ───────────────────────────────────────────────────────
        // 🚫 COMANDOS NÃO DÃO XP
        // ───────────────────────────────────────────────────────

        const prefixo =
            config.PREFIX || ".";

        if (
            textoMensagem.trim()
                .startsWith(prefixo)
        ) {
            return;
        }


        // ───────────────────────────────────────────────────────
        // 👤 DADOS DO USUÁRIO
        // ───────────────────────────────────────────────────────

        const usuarioId =
            msg.key.participant;

        const grupoId =
            msg.key.remoteJid;

        const nomeUsuario =
            msg.pushName?.trim() ||
            "Viajante";


        // ───────────────────────────────────────────────────────
        // 📂 CARREGA BANCO
        // ───────────────────────────────────────────────────────

        const db = loadDB();

        const usuario =
            garantirUsuario(
                db,
                usuarioId,
                nomeUsuario
            );


        // ───────────────────────────────────────────────────────
        // 🔄 ATUALIZA DADOS
        // ───────────────────────────────────────────────────────

        usuario.nome =
            nomeUsuario;

        usuario.ultimaAtividade =
            Date.now();


        // ───────────────────────────────────────────────────────
        // ⚡ ADICIONA XP
        // ───────────────────────────────────────────────────────

        const xpGanho =
            gerarXP();

        usuario.xp += xpGanho;


        // ───────────────────────────────────────────────────────
        // 🆙 VERIFICA LEVEL UP
        // ───────────────────────────────────────────────────────

        while (
            usuario.xp >=
            usuario.nivel * 150
        ) {

            const xpNecessario =
                usuario.nivel * 150;


            // Remove XP utilizado
            usuario.xp -=
                xpNecessario;


            // Sobe o nível
            usuario.nivel += 1;


            // ───────────────────────────────────────────────
            // 🪙 RECOMPENSA
            // ───────────────────────────────────────────────

            const recompensaOuro =
                usuario.nivel * 50;

            usuario.ouro +=
                recompensaOuro;


            // ───────────────────────────────────────────────
            // 👤 IDENTIFICAÇÃO
            // ───────────────────────────────────────────────

            const nomeExibicao =
                usuarioId.split("@")[0];


            // ───────────────────────────────────────────────
            // 🎉 MENSAGEM DE LEVEL UP
            // ───────────────────────────────────────────────

            const legendaSubida = `
〔 🎉 𝐋𝐄𝐕𝐄𝐋 𝐔𝐏 〕
『 🆙 𝐍𝐎𝐕𝐎 𝐍𝐈́𝐕𝐄𝐋 』
    └─ @${nomeExibicao}
        └─ Você subiu de nível!
━━━━━━━━━━━━━━
> 📈 𝐍𝐈́𝐕𝐄𝐋
   └─ ${usuario.nivel}
> 🪙 𝐑𝐄𝐂𝐎𝐌𝐏𝐄𝐍𝐒𝐀
   └─ +${recompensaOuro} moedas de ouro
━━━━━━━━━━━━━━
🤍 ${config.BOT_NAME}
🌹 ${config.OWNER_NAME}
━━━━━━━━━━━━━━`;


            // ───────────────────────────────────────────────
            // 🖼️ FOTO DE PERFIL
            // ───────────────────────────────────────────────

            let fotoBuffer = null;

            try {

                const fotoUrl =
                    await sock.profilePictureUrl(
                        usuarioId,
                        "image"
                    );

                if (fotoUrl) {

                    fotoBuffer =
                        await baixarBuffer(
                            fotoUrl
                        );
                }

            } catch {
                fotoBuffer = null;
            }


            // ───────────────────────────────────────────────
            // 🏞️ FOTO DE CONTEXTO
            // ───────────────────────────────────────────────

            let fotoContextoBuffer = null;

            try {

                fotoContextoBuffer =
                    await buscarFotoContexto(
                        sock,
                        grupoId
                    );

            } catch {

                fotoContextoBuffer =
                    null;
            }


            // ───────────────────────────────────────────────
            // 🎨 GERA E ENVIA CARD
            // ───────────────────────────────────────────────

            try {

                await enviarCardOuAnimado(sock, grupoId, (fundoBuffer) => criarCardLevelUp({
                        fotoBuffer,
                        nomeUsuario:
                            nomeExibicao,
                        novoNivel:
                            usuario.nivel,
                        ouroGanho:
                            recompensaOuro,
                        fotoContextoBuffer,
                        fundoBuffer
                    }), {
                        caption:
                            legendaSubida,
                        mentions: [
                            usuarioId
                        ]
                    });


            } catch (erroCard) {

                console.error(
                    "❌ Erro no card de Level Up:",
                    erroCard
                );


                // ───────────────────────────────────────────
                // 📢 FALLBACK
                // ───────────────────────────────────────────

                try {

                    await sock.sendMessage(
                        grupoId,
                        {
                            text:
                                legendaSubida,
                            mentions: [
                                usuarioId
                            ]
                        }
                    );

                } catch (erroFallback) {

                    console.error(
                        "❌ Erro no fallback do Level Up:",
                        erroFallback
                    );
                }
            }
        }


        // ───────────────────────────────────────────────────────
        // 💾 SALVA BANCO
        // ───────────────────────────────────────────────────────

        saveDB(db);

    } catch (erro) {

        console.error(
            "❌ Erro no sistema de Level:",
            erro
        );
    }
}


// ═══════════════════════════════════════════════════════════════
// 💰 ADICIONAR OURO
// ═══════════════════════════════════════════════════════════════

async function addGold(
    usuarioId,
    quantidade
) {

    if (
        !usuarioId ||
        !Number.isFinite(quantidade) ||
        quantidade <= 0
    ) {
        return false;
    }


    const valor =
        Math.floor(quantidade);


    if (valor <= 0) {
        return false;
    }


    const db =
        loadDB();


    const usuario =
        garantirUsuario(
            db,
            usuarioId,
            "Usuário"
        );


    usuario.ouro +=
        valor;


    saveDB(db);


    console.log(
        `[💰 OURO] +${valor} → ${usuarioId}`
    );


    return true;
}


// ═══════════════════════════════════════════════════════════════
// 📉 REMOVER OURO
// ═══════════════════════════════════════════════════════════════

async function removeGold(
    usuarioId,
    quantidade
) {

    if (
        !usuarioId ||
        !Number.isFinite(quantidade) ||
        quantidade <= 0
    ) {
        return 0;
    }


    const valorSolicitado =
        Math.floor(quantidade);


    if (valorSolicitado <= 0) {
        return 0;
    }


    const db =
        loadDB();


    if (!db[usuarioId]) {
        return 0;
    }


    const usuario =
        garantirUsuario(
            db,
            usuarioId,
            "Usuário"
        );


    // Nunca permite saldo negativo
    const valorRemovido =
        Math.min(
            valorSolicitado,
            usuario.ouro
        );


    usuario.ouro -=
        valorRemovido;


    saveDB(db);


    console.log(
        `[💰 OURO] -${valorRemovido} → ${usuarioId}`
    );


    return valorRemovido;
}


// ═══════════════════════════════════════════════════════════════
// 💳 CONSULTAR SALDO
// ═══════════════════════════════════════════════════════════════

function getBalance(usuarioId) {

    if (!usuarioId) {

        return {
            nivel: 1,
            xp: 0,
            ouro: 0
        };
    }


    const db =
        loadDB();


    if (!db[usuarioId]) {

        return {
            nivel: 1,
            xp: 0,
            ouro: 0
        };
    }


    return db[usuarioId];
}


// ═══════════════════════════════════════════════════════════════
// 📦 EXPORTAÇÕES
// ═══════════════════════════════════════════════════════════════

module.exports = {
    processLevel,
    loadDB,
    saveDB,
    addGold,
    removeGold,
    getBalance
};