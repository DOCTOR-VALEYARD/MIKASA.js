const config = require("../config");
async function menugold(sock, msg) {
    const from = msg.key.remoteJid;
    const resposta = `🌸┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌸
✨ 『 ${config.BOT_NAME} 』✨
🌸┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌸

   💰 𝑴𝑬𝑵𝑼 𝑮𝑶𝑳𝑫 💰

🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
   💸 𝑬𝑪𝑶𝑵𝑶𝑴𝑰𝑨 & 𝑴𝑶𝑬𝑫𝑨𝑺
🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
🌸 ${config.PREFIX}saldo ➜ Ver saldo Gold
🌸 ${config.PREFIX}roubar [@user] ➜ Roubar Gold
🌸 ${config.PREFIX}loja ➜ Comprar itens
🌸 ${config.PREFIX}duelo [@user] ➜ Apostar Gold
🌸 ${config.PREFIX}resgatar ➜ Resgatar token

🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
   🏆 𝑹𝑨𝑵𝑲𝑰𝑵𝑮
🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
🌸 ${config.PREFIX}rank ➜ Ver ranking
🌸 ${config.PREFIX}perfil ➜ Seu perfil

🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
   📊 𝑪𝑶𝑵𝑽𝑬𝑹𝑺𝑨̃𝑶
🌷┈┈┈┈┈┈┈┈┈┈┈┈┈┈🌷
🌸 1000 Gold = 1 Premium
💐┈┈┈┈┈┈┈┈┈┈┈┈┈┈💐`;
    await sock.sendMessage(from, { text: resposta }, { quoted: msg });
}
module.exports = { menugold };
