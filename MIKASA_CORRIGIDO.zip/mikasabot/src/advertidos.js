const config = require("../config");
async function advertidos(sock, msg) {
    const from = msg.key.remoteJid;
    const resp = `
╭─┅┄『 ⚠️ *ADVERTIDOS* 』┄┅
│
│ 『 📋 』 LISTA DE ADVERTIDOS: VAZIO
│ 『 💡 』 NINGUÉM FOI ADVERTIDO AINDA
╰┅┄┅『   ✦mikasa bot✦   』┄┅`;
    await sock.sendMessage(from, { text: resp }, { quoted: msg });
}
module.exports = { advertidos };
