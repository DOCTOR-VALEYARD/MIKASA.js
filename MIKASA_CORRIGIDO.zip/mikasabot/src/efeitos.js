const config = require("../config");
const fs = require("fs");
const path = require("path");
const { execSync } = require("child_process");
const { downloadMediaMessage } = require("@whiskeysockets/baileys");
const pino = require("pino");


async function efeitos(sock, msg, args) {
    args = args || [];

    const from = msg.key.remoteJid;
    const sender = msg.key.participant || msg.key.remoteJid;
    const dataAtual = new Date().toLocaleString("pt-BR");
    let ambiente = "Privado";
    if (from.endsWith("@g.us")) ambiente = `Grupo`;


    // 📋 DETECTA: MENSAGEM DIRETA OU RESPONDIDA — ESSENCIAL PARA RC9
    let mensagemParaProcessar = null;
    let imagem = null;

    if (msg.message?.imageMessage) {
        mensagemParaProcessar = msg;
        imagem = msg.message.imageMessage;
    }
    else if (msg.message?.extendedTextMessage?.contextInfo?.quotedMessage?.imageMessage) {
        const citada = msg.message.extendedTextMessage.contextInfo.quotedMessage;
        mensagemParaProcessar = {
            key: msg.message.extendedTextMessage.contextInfo.quotedKey,
            message: citada,
            messageTimestamp: msg.messageTimestamp,
            pushName: msg.pushName
        };
        imagem = citada.imageMessage;
    }


    if (!imagem || !mensagemParaProcessar) {
        const resp = `
┅┄┅┄『 ✦ 』┄┅┄┅┄
『 ✦ 』${config.BOT_NAME}『 ✦ 』
┅┄┅┄『 ✦ 』┄┅┄┅┄

  🎨 EFEITOS DE IMAGEM 🎨
📅 ${dataAtual}

┅┄┅┄『 ✦ 』┄┅┄┅┄
『 ✦ 』 1 — Banner
『 ✦ 』 2 — Pixelado
『 ✦ 』 3 — Foco / Nitidez
『 ✦ 』 4 — Recorte Circular ✅
『 ✦ 』 5 — Preto & Branco
『 ✦ 』 6 — Tom Sépia / Antigo
┅┄┅┄『 ✦ 』┄┅┄┅┄

💡 COMO USAR:
Responda uma foto com:
${config.PREFIX}efeitos NÚMERO
Exemplo: ${config.PREFIX}efeitos 3

┅┄┅┄『 ✦ 』┄┅┄┅┄
By | ${config.OWNER_NAME}
📍 ${ambiente}
┅┄┅┄『 ✦ 』┄┅┄┅┄
`;
        return await sock.sendMessage(from, { text: resp }, { quoted: msg });
    }


    // 🎨 VALIDA NÚMERO
    const escolha = args[0]?.trim();
    if (!escolha || isNaN(escolha) || escolha < 1 || escolha > 6) {
        return await sock.sendMessage(from, {
            text: `┅┄┅┄『 ✦ 』┄┅┄┅┄
⚠️ AVISO
Escolha um número entre 1 e 6!
┅┄┅┄『 ✦ 』┄┅┄┅┄`
        }, { quoted: msg });
    }


    // ⏳ AVISO
    await sock.sendMessage(from, {
        text: `┅┄┅┄『 ✦ 』┄┅┄┅┄
⏳ PROCESSANDO
Aplicando efeito: ${escolha} ...
Aguarde um instante...
┅┄┅┄『 ✦ 』┄┅┄┅┄`
    }, { quoted: msg });


    try {
        // 📂 PASTA TEMP COM PERMISSÕES
        const pastaTemp = path.join(__dirname, "..", "temp");
        if (!fs.existsSync(pastaTemp)) fs.mkdirSync(pastaTemp, { recursive: true, mode: 0o777 });

        const caminhoEntrada = path.join(pastaTemp, `entrada_${Date.now()}.jpg`);
        const caminhoSaida = path.join(pastaTemp, `saida_${Date.now()}.png`);


        // ✅ BAIXA CORRETO PARA RC9
        const buffer = await downloadMediaMessage(
            mensagemParaProcessar,
            'buffer',
            {},
            {
                logger: pino({ level: 'silent' }),
                reuploadRequest: sock.updateMediaMessage
            }
        );

        fs.writeFileSync(caminhoEntrada, buffer);


        // 🎨 COMANDOS — TODOS REESCRITOS, ESPECIALMENTE O NÚMERO 4!
        let comando = "";
        switch (escolha) {
            // 1 — Banner
            case "1":
                comando = `convert "${caminhoEntrada}" -resize 850x480^ -gravity center -extent 850x480 -border "#1a1a1a" 12 -quality 92 "${caminhoSaida}"`;
                break;

            // 2 — Pixelado
            case "2":
                comando = `convert "${caminhoEntrada}" -scale 6% -scale 1600% -quality 100 "${caminhoSaida}"`;
                break;

            // 3 — Foco / Nitidez
            case "3":
                comando = `convert "${caminhoEntrada}" -normalize -sharpen 0x2.0 -contrast-stretch 2x2% "${caminhoSaida}"`;
                break;

            // ✅✅✅ NÚMERO 4 — VERSÃO GARANTIDA PARA TERMUX! SEM ERRO NENHUM!
            case "4":
                comando = `convert -size 550x550 xc:none -fill "${caminhoEntrada}" -draw "circle 275,275 275,2" "${caminhoSaida}"`;
                break;

            // 5 — Preto & Branco
            case "5":
                comando = `convert "${caminhoEntrada}" -colorspace Gray -auto-level "${caminhoSaida}"`;
                break;

            // 6 — Sépia / Antigo
            case "6":
                comando = `convert "${caminhoEntrada}" -colorspace Gray -sepia-tone 65% -brightness-contrast +5x10 "${caminhoSaida}"`;
                break;
        }


        // ⚙️ EXECUÇÃO SEGURA
        execSync(comando, { stdio: ["ignore", "ignore", "ignore"] });


        if (!fs.existsSync(caminhoSaida)) throw new Error("Arquivo não foi criado");


        // 📤 ENVIO PRONTO
        const bufferFinal = fs.readFileSync(caminhoSaida);
        await sock.sendMessage(from, {
            image: bufferFinal,
            caption: `┅┄┅┄『 ✦ 』┄┅┄┅┄
✅ EFEITO APLICADO COM SUCESSO
🎨 Efeito: ${escolha}
📸 Imagem pronta!
📍 ${ambiente}
┅┄┅┄『 ✦ 』┄┅┄┅┄`,
            mentions: [sender]
        }, { quoted: msg });


        // 🧹 LIMPEZA TOTAL
        try { fs.unlinkSync(caminhoEntrada); } catch (e) {}
        try { fs.unlinkSync(caminhoSaida); } catch (e) {}


    } catch (erro) {
        console.log("\n❌ === ERRO DETALHADO === ❌");
        console.log(erro);
        console.log("===========================\n");

        await sock.sendMessage(from, {
            text: `┅┄┅┄『 ✦ 』┄┅┄┅┄
❌ FALHA NO PROCESSAMENTO
Tente novamente com outra foto.
┅┄┅┄『 ✦ 』┄┅┄┅┄`
        }, { quoted: msg });
    }
}

module.exports = { efeitos };

